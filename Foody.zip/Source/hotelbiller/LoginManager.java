/*
 * This class represents the login screen that authenticates the users before they access the main panel
 */
package hotelbiller;

import com.sun.glass.events.KeyEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Properties;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Eric
 */
public class LoginManager extends JFrame implements ActionListener{
private final JButton admin,exit,standard,backTo;
private final JPasswordField userPwd;
public static Properties loginDetails,logins;
public static Image icon;
private final JLabel message,waitup;
private static final String MODULE="LoginManager:";
private final JPanel accounts,pPane;
private final Color all=MotherFrame.THEMECOLOR;
private final File events=new File("resources/system.dll");
/**
 * Public constructor of this class
*/
public LoginManager()
{
this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();
int width=900,height=600;
this.setSize(width,height);
int h=((screen.height)-height)/2;
int w=((screen.width)-width)/2;
Point p=new Point(w,h);
this.setLocation(p);
this.setLayout(new GridLayout(3,1));
message=new JLabel("Login As");
message.setHorizontalAlignment(SwingConstants.CENTER);
message.setFont(new Font(Font.SANS_SERIF,Font.BOLD,30));
waitup=new JLabel("Welcome \n");
waitup.setHorizontalAlignment(SwingConstants.CENTER);
waitup.setFont(new Font(Font.SANS_SERIF,Font.BOLD,25));
waitup.setIconTextGap(10);
waitup.setIcon(new ImageIcon("resources/waiting.gif"));
backTo=new JButton("");
backTo.setFocusable(true);
backTo.setMnemonic(KeyEvent.VK_BACKSPACE);
backTo.setToolTipText("Back");
backTo.addActionListener(this);
backTo.setPreferredSize(new Dimension(80,50));
exit=new JButton("");
exit.setToolTipText("Exit Foodie");
exit.addActionListener(this);
exit.setMnemonic(KeyEvent.VK_E);
exit.setPreferredSize(new Dimension(52,52));
admin=new JButton("");
admin.setToolTipText("Login as Administrator");
admin.setFocusable(true);
admin.setMnemonic(KeyEvent.VK_A);
admin.addActionListener(this);
admin.setPreferredSize(new Dimension(160,160));
admin.setBorder(BorderFactory.createTitledBorder(null,"ADMINISTRATOR",TitledBorder.CENTER,TitledBorder.ABOVE_TOP));
standard=new JButton("");
standard.setMnemonic(KeyEvent.VK_S);
standard.setToolTipText("Login as standard user");
standard.addActionListener(this);
standard.setFocusable(true);
standard.setPreferredSize(new Dimension(160,160));
standard.setBorder(BorderFactory.createTitledBorder(null,"STANDARD",TitledBorder.CENTER,TitledBorder.ABOVE_TOP));
userPwd=new JPasswordField(20);
userPwd.setToolTipText("Enter Password");
userPwd.setPreferredSize(new Dimension(150,55));
userPwd.addActionListener(this);
userPwd.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.WHITE),
        "PASSWORD",TitledBorder.CENTER,TitledBorder.BELOW_BOTTOM));
userPwd.setHorizontalAlignment(SwingConstants.CENTER);
userPwd.setFocusable(true);
userPwd.setEchoChar('*');
accounts=new JPanel();
accounts.setSize(800,200);
int x=((height-350)/2),y=((width-400)/2);
accounts.setLocation(new Point(x,y));
pPane=new JPanel();
pPane.setLayout(new BorderLayout());
pPane.setBackground(Color.WHITE);
pPane.setBorder(BorderFactory.createLineBorder(Color.WHITE));
pPane.add(userPwd,BorderLayout.CENTER);
pPane.add(backTo,BorderLayout.EAST);
accounts.add(admin);
accounts.add(standard);
JPanel space=new JPanel(),exitPane=new JPanel();
exitPane.add(exit);
space.setBackground(all);
exitPane.setBackground(all);
space.add(message);
this.add(space);
this.add(accounts);
this.add(exitPane);
//this.add(accounts,BorderLayout.CENTER);
loginDetails=new Properties();
decorateComponents();
accounts.setLocation(600,200);
}
public void lockSystem()
{

String WHERE="lockSystem()";
try
{
if(events.exists())
{
   ObjectInputStream in=new ObjectInputStream(new FileInputStream(events));
   logins=(Properties) in.readObject();
   in.close();
}
accounts.remove(pPane);
accounts.add(admin);
accounts.add(standard);
userPwd.setText("");
this.setVisible(true);
}
catch(FileNotFoundException e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getLocalizedMessage());
}
catch(IOException e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getLocalizedMessage());
}
catch(ClassNotFoundException e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getLocalizedMessage());
}
}
/**
 * Adds some decoration to the components on this frame such as 
 * setting the color and image icons
 */
private void decorateComponents()
{
ImageIcon std=null,adm=null,back=null,ext=null;
String WHERE="decorateComponnents():";
try
{
    message.setBackground(Color.BLUE);
    message.setForeground(Color.WHITE);
    standard.setBackground(Color.WHITE);
    admin.setBackground(Color.WHITE);
    backTo.setBackground(Color.WHITE);
    backTo.setBorderPainted(false);
    exit.setBackground(all);
    std=new ImageIcon("resources/std.png");
    adm=new ImageIcon("resources/adm.png");
    back=new ImageIcon("resources/back.png");
    ext=new ImageIcon("resources/exit.png");
    exit.setIcon(ext);
    standard.setIcon(std);
    admin.setIcon(adm);
    backTo.setIcon(back);
    icon=ImageIO.read(new File("resources/icon.png"));
    this.setIconImage(icon);
this.setBackground(all);
this.setForeground(Color.WHITE);
accounts.setBackground(this.getBackground());
userPwd.setFont(new Font(Font.MONOSPACED,Font.BOLD,25));
userPwd.setAlignmentX(javax.swing.JComponent.CENTER_ALIGNMENT);
}
catch(Exception e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
if(std==null){standard.setText("Standard User");}
if(adm==null){admin.setText("Administrator");}
if(back==null){backTo.setText("Back");}
if(ext==null){exit.setText("Exit");}
}
this.setBackground(all);
this.setForeground(Color.WHITE);
accounts.setBackground(this.getBackground());
userPwd.setFont(new Font(Font.MONOSPACED,Font.BOLD,25));
userPwd.setAlignmentX(javax.swing.JComponent.CENTER_ALIGNMENT);
}
/**
 * handles the button clicks events in the class
 * @param src is the clicked button-source of the event 
 */
private void doPaint()
{
this.revalidate();
this.repaint();
}
private void buttonClicked(JButton src)
{
if(src.equals(admin))
{
loginDetails.clear();
loginDetails.put("user","ADMIN");
if(!isLocked())
{
loginUser();
}
else
{
userPwd.setToolTipText("Enter Administrator's Password");
userPwd.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.WHITE),
        "ADMINISTRATOR PASSWORD",TitledBorder.CENTER,TitledBorder.BELOW_BOTTOM));
demandPassword();
}
}
else if(src.equals(standard))
{
loginDetails.clear();
loginDetails.put("user","STANDARD");
if(!isLocked())
{
loginUser();
}
else
{
userPwd.setToolTipText("Enter User Password");
userPwd.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.WHITE),
        "USER PASSWORD",TitledBorder.CENTER,TitledBorder.BELOW_BOTTOM));
demandPassword();
}
}
else if(src.equals(backTo))
{
message.setText("Login As");
message.setForeground(Color.WHITE);
accounts.remove(pPane);
accounts.add(admin);
accounts.add(standard);
this.doPaint();
}
else if(src.equals(exit))
{
System.exit(0);
}
}
private void demandPassword()
{
accounts.remove(admin);
accounts.remove(standard);
accounts.add(pPane);
this.doPaint();
}
@Override
public void actionPerformed(ActionEvent e) 
{
    if(e.getSource() instanceof JButton){buttonClicked((JButton) e.getSource());}
    else if(e.getSource().equals(userPwd))
    {
    this.authenticate();
    }
}
private boolean isLocked()
{
boolean locked=true;
String us=(String) loginDetails.get("user"),WHERE="isLocked()";
try
{
if(logins!=null)
{
int isLocked=Integer.parseInt(""+logins.getProperty("is"+us));
switch(isLocked)
{
    case 0:
        locked=false;
        MotherFrame.unlock.setText("Lock Account");
        break;
    case 1:
        locked=true;
        MotherFrame.unlock.setText("UnLock Account");
        break;
}
}
}
catch(Exception e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
return locked;
}
return locked;
}
private void loginUser()
{
String user=(String)loginDetails.get("user");
accounts.removeAll();
accounts.add(waitup);
this.doPaint();
MotherFrame mainApp=new MotherFrame(user);
this.setVisible(false);
mainApp.setVisible(true);
}
private void authenticate() 
{
    String WHERE="authenticate():";
    try 
    {
        if(logins!=null)
        {
        String us=(String) loginDetails.getProperty("user");
        char[] pass=(char[])logins.get(us);
            if(Arrays.equals(pass,userPwd.getPassword()))
            {
              loginUser();
            }
            else
            {
            message.setText("WRONG PASSWORD.PLEASE TRY AGAIN");
            message.setForeground(Color.red);
            Toolkit.getDefaultToolkit().beep();
            }
        }
    } 
    catch (Exception e) 
    {
      HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getLocalizedMessage());
    }
    }
}