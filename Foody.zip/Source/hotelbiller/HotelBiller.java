/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelbiller;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


/**
 * @author Eric Kamunge
 */
public class HotelBiller {
//Database
public static String pwd;//="";
public static String userN;//="root";
public static String DB_URL;//="jdbc:mysql://localhost:3306/motel";
public static String DB_Driver="com.mysql.jdbc.Driver";
public static Image icon;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Thread t;
        try 
        {
            javax.swing.UIManager.setLookAndFeel(new javax.swing.plaf.nimbus.NimbusLookAndFeel());
            ErrorLogger logger=new ErrorLogger();
            t=new Thread(logger);
            t.start();
         try
         {
          icon=ImageIO.read(new File("resources/icon.png"));
         }
         catch(IOException e)
         {
         queueError("main(String[])"+e.toString()+":"+e.getMessage());
         }
        ConfigurationPanel.configureAndStart();
        }
        catch(Exception ex) 
        {
         queueError("HotelBiller-> main()-> "+ex.toString()+" "+ex.getMessage());
        }
        ErrorLogger.ERRORQUEUE.flush();
        ErrorLogger.ERRORQUEUE.close();
    }
    public static void queueError(String err)
    {
    try
    {
    ErrorLogger.ERRORQUEUE.println("("+new java.util.Date().toString().substring(0,16)+"): "+err);
    ErrorLogger.ERRORQUEUE.flush();
    }
    catch(Exception ex)
    {
    System.out.println("Error Logger Encountered a problem"+ex.toString());
    }
    }
}