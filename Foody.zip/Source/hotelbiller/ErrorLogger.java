package hotelbiller;

import java.io.File;
import java.io.PrintStream;

/**
 * @author Eric Kamunge
 */
public class ErrorLogger implements Runnable{
public static PrintStream ERRORQUEUE;
@Override
public void run()
{
File errorLog=new File("resources/Poison.fp");
try
{
if(!errorLog.exists())
     {
     errorLog.createNewFile();
     }
     ERRORQUEUE=new PrintStream(errorLog);
while(1==1)
{
  ERRORQUEUE.flush();
}
}
catch(Exception ex)
{
System.out.println("Logging Error encountered."+ ex.toString()+":"+ex.getLocalizedMessage());
}
}
}