/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelbiller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Eric
 */
public class SecurityPanel extends JDialog{
private final EventsHandler eventsHandler;
private final JPasswordField pass1,pass2,pass;
private final JButton change,cancel,next;
private final JPanel step1,step2,buttons;
private static final String MODULE="SecurityPanel:";

public SecurityPanel()
{
this.setIconImage(MotherFrame.icon);
this.setModal(true);
this.setSize(400,400);
this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
this.setLayout(new BorderLayout());
this.setResizable(false);
this.setBackground(Color.WHITE);
eventsHandler=new EventsHandler();
pass=new JPasswordField();
pass.addActionListener(eventsHandler);
pass.setFont(new Font(Font.MONOSPACED,Font.BOLD,20));
pass1=new JPasswordField();
pass2=new JPasswordField();
pass.setPreferredSize(new Dimension(250,80));
pass1.setPreferredSize(new Dimension(250,80));
pass2.setPreferredSize(new Dimension(250,80));
pass.setEchoChar('*');pass1.setEchoChar('*');pass2.setEchoChar('*');
pass.setBorder(BorderFactory.createTitledBorder(null,"ENTER CURRENT PASSWORD",TitledBorder.CENTER,TitledBorder.BELOW_BOTTOM));
pass1.setBorder(BorderFactory.createTitledBorder(null,"NEW PASSWORD",TitledBorder.CENTER,TitledBorder.ABOVE_TOP));
pass2.setBorder(BorderFactory.createTitledBorder(null,"RE-ENTER NEW PASSWORD",TitledBorder.CENTER,TitledBorder.ABOVE_TOP));
pass1.setFont(new Font(Font.MONOSPACED,Font.BOLD,20));
pass2.setFont(new Font(Font.MONOSPACED,Font.BOLD,20));
next=new JButton("Next");
change=new JButton("Change");
cancel=new JButton("Cancel");
change.setPreferredSize(new Dimension(80,30));
cancel.setPreferredSize(new Dimension(80,30));
next.setPreferredSize(new Dimension(80,30));
next.addActionListener(eventsHandler);
change.addActionListener(eventsHandler);
cancel.addActionListener(eventsHandler);
step1=new JPanel();
step1.setBackground(Color.ORANGE);
buttons=new JPanel();
buttons.add(cancel);
buttons.add(next);
step1.setLayout(new GridLayout(3,1));
JPanel h=new JPanel();
h.add(pass);
h.setBackground(Color.WHITE);
step1.add(new JPanel());
step1.setBackground(Color.WHITE);
step1.add(h);
step1.add(new JPanel());
step2=new JPanel();
step2.setBackground(Color.WHITE);
step2.add(pass1);
step2.add(pass2);
JPanel nrt=new JPanel();
nrt.setSize(new Dimension(this.getWidth(),40));
this.add(nrt,BorderLayout.NORTH);
this.add(step1,BorderLayout.CENTER);
this.add(buttons,BorderLayout.SOUTH);
}
private void toStepTwo()
{
String WHERE="toStepTwo():";
try 
{
if(MotherFrame.teller!=null&&MotherFrame.teller.containsKey(MotherFrame.PRIVILEGE))
{
    char[] keys=(char[])MotherFrame.teller.get(MotherFrame.PRIVILEGE);
    if(Arrays.equals(pass.getPassword(),keys))
    {
      this.proceed();
    }
    else
    {
    Toolkit.getDefaultToolkit().beep();
    pass.setBorder(BorderFactory.createTitledBorder(null,"INCORRECT PASSWORD",TitledBorder.CENTER,TitledBorder.BELOW_BOTTOM));
    }
}
}
catch (Exception e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
}
}
private void proceed()
{
this.remove(step1);
buttons.removeAll();
buttons.add(cancel);
buttons.add(change);
this.add(step2,BorderLayout.CENTER);
this.revalidate();
this.repaint();
}
private void buttonClicked(JButton src)
{
String WHERE="buttonClicked(JButton):";
try
{
if(src.equals(cancel))
{
this.setVisible(false);
pass.setText("");
pass1.setText("");
pass2.setText("");
}
else if(src.equals(next))
{
toStepTwo();
}
else if(src.equals(change))
{
changePassword();
}
}
catch(Exception e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
}

}
private void changePassword()
{
String userN=MotherFrame.PRIVILEGE;
if(Arrays.equals(pass1.getPassword(),pass2.getPassword()))
{
MotherFrame.teller.put(MotherFrame.PRIVILEGE,pass1.getPassword());
{
MotherFrame.updateLogins();
JOptionPane.showMessageDialog(this,
        "Your password has been changed.\nYou will use the new passowrd next time you log in as "+userN,
        "PASSWORD CHANGED",JOptionPane.INFORMATION_MESSAGE);
this.setVisible(false);
}
}
else
{
pass1.setText("");
pass2.setText("");
JOptionPane.showMessageDialog(this,
        "The Passwords you entered do not match.\nPlease try again.",
        "PASSWORD MISMATCH",JOptionPane.WARNING_MESSAGE);
}
}
private class EventsHandler implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e)
        {
          if(e.getSource() instanceof JButton)
          {
          buttonClicked((JButton) e.getSource());
          }
          else if(e.getSource().equals(pass))
          {
          toStepTwo();
          }
        }


}
}
