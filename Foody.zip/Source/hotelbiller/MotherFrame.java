/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hotelbiller;

import drawables.Calculator;
import drawables.EventsCalender;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Properties;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import records.BackupCreator;
import records.Reporter;
import tabberView.TabberView;
/**
 *
 * @author Eric Kamunge
 * @email kamungeeric@gmail.com
 */
public class MotherFrame extends JFrame{
private static final JSplitPane splitter=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
private static final JPanel centerPanel=new JPanel(),
        leftPanel=new JPanel(),
        toolBar=new JPanel();
private JMenu file=new JMenu("Options"),
        security=new JMenu("Security"),
        tools=new JMenu("Tools");
private JMenuItem exit=new JMenuItem("Exit Foodie"),
        report=new JMenuItem("Create Report"),
        backup=new JMenuItem("Back Up"),
        password=new JMenuItem("Change password"),
        calc=new JMenuItem("Calculator");
public static final String[] MEALCATEGORIES={"Drink","Dish","Snack","Dessert","Special","Soft Drink","Soup"};
public static JMenuItem unlock=new JMenuItem("Unlock Account");
private JButton backupTool=new JButton(),
        calculatorTool=new JButton(),
        calender=new JButton(),
        reportGen=new JButton();

public static Font tableFont=new Font(Font.SERIF,Font.BOLD,15);
private Container contentPane=this.getContentPane();
private static TabberView tabs;
private static EventsCalender eventsCalender;
private JMenuBar menuBar=new JMenuBar();
public static Image icon;
private static EventsHandler eventsHandler;
private  static Reporter reporter;
private ImageIcon rGen,calIcon,calen,fRep;
public static  String PRIVILEGE;
public static final Color THEMECOLOR=Color.decode("#4caf50");
public static final Color SEARCHCOLOR=Color.decode("#4cee50");
private final Calculator calculator;
private final BackupCreator backupCreator;
private SecurityPanel securityPanel;
private final JDialog ACCOUNTLOCK;
private final JButton cancel,toggle;
private final JPasswordField pass;
private static final String MODULE="MOTHERFRAME:";
public static Properties teller;
public static String MY_ID;
public MotherFrame(String user)
{
PRIVILEGE=user;
teller=LoginManager.logins;
String WHERE="Constructor->";
this.setJMenuBar(menuBar);
this.setBackground(THEMECOLOR);
Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();
this.setSize(screen.width-20,screen.height-30);
Point p=new Point(10,10);
this.setLocation(p);
this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
icon=HotelBiller.icon;
this.setIconImage(icon);
this.getIcons();
eventsCalender=new EventsCalender();
eventsCalender.setBackground(THEMECOLOR);
backupCreator=new BackupCreator();
calculator=new Calculator();
tabs=new TabberView();
tabs.setBackground(THEMECOLOR);
this.setTitle("FOODY POS TERMINAL");
eventsHandler=new EventsHandler();
leftPanel.setBorder(BorderFactory.createTitledBorder(""));
leftPanel.setBackground(THEMECOLOR);
leftPanel.setLayout(new GridLayout(4,1));
reportGen.addActionListener(eventsHandler);
reportGen.setPreferredSize(new Dimension(150,150));
backupTool.setToolTipText("Records backup");
backupTool.setPreferredSize(new Dimension(150,150));
backupTool.addActionListener(eventsHandler);
calculatorTool.setToolTipText("Calculator");
calculatorTool.setPreferredSize(new Dimension(150,150));
calculatorTool.addActionListener(eventsHandler);
calender.setToolTipText("Calender of Events");
calender.setPreferredSize(new Dimension(150,150));
calender.addActionListener(eventsHandler);
reportGen.setToolTipText("Report Generator");
leftPanel.setForeground(Color.WHITE);
leftPanel.add(backupTool);
leftPanel.add(calculatorTool);
leftPanel.add(calender);
leftPanel.add(reportGen);
//
ACCOUNTLOCK=new JDialog();
ACCOUNTLOCK.setModal(true);
ACCOUNTLOCK.setLocationRelativeTo(this);
ACCOUNTLOCK.setSize(400,200);
ACCOUNTLOCK.setBackground(THEMECOLOR);
ACCOUNTLOCK.setLayout(new BorderLayout());
ACCOUNTLOCK.setIconImage(icon);
ACCOUNTLOCK.setTitle(unlock.getText()+" "+PRIVILEGE);
ACCOUNTLOCK.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
pass=new JPasswordField();
pass.setPreferredSize(new Dimension(150,50));
pass.setFont(new Font(Font.MONOSPACED,Font.BOLD|Font.ITALIC,30));
pass.setHorizontalAlignment(SwingConstants.CENTER);
pass.setText("..........");
pass.addActionListener(eventsHandler);
pass.setBorder(BorderFactory.createTitledBorder(null,"ENTER CURRENT PASSWORD", TitledBorder.ABOVE_BOTTOM,TitledBorder.CENTER));
cancel=new JButton("Cancel");
cancel.setMnemonic('C');
cancel.setPreferredSize(new Dimension(100,40));
cancel.addActionListener(eventsHandler);
toggle=new JButton(unlock.getText().substring(0,unlock.getText().indexOf(" ")));
toggle.setPreferredSize(new Dimension(100,40));
toggle.addActionListener(eventsHandler);
toggle.setMnemonic('L');
JPanel b=new JPanel();
b.add(cancel);
b.add(toggle);
b.setBackground(THEMECOLOR);
ACCOUNTLOCK.add(b,BorderLayout.SOUTH);
ACCOUNTLOCK.add(pass,BorderLayout.CENTER);
//
JMenuItem[] menus={exit,report,backup,password,unlock,calc};
for(JMenuItem f:menus)
{
    f.addActionListener(eventsHandler);
    f.setBackground(THEMECOLOR);
    f.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,15));
}
//
file.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,15));
file.add(exit);
file.setBackground(THEMECOLOR);
//
tools.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,15));
tools.setBackground(THEMECOLOR);
tools.add(calc);
tools.add(report);
tools.add(backup);
//
security.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,15));
security.setBackground(THEMECOLOR);
security.add(password);
security.add(unlock);
//
menuBar.setBackground(THEMECOLOR);
menuBar.add(file);
menuBar.add(tools);
menuBar.add(security);
//
centerPanel.setLayout(new BorderLayout());
toolBar.setBackground(THEMECOLOR);
contentPane.add(toolBar,BorderLayout.NORTH);
centerPanel.add(tabs,BorderLayout.CENTER);
splitter.setDividerLocation(200);
splitter.setBackground(THEMECOLOR);
splitter.setOneTouchExpandable(true);
splitter.add(new JScrollPane(leftPanel),0);
splitter.add(centerPanel,1);
contentPane.add(splitter);
reporter=new Reporter();
}
public static void updateLogins()
{
    String WHERE="updateLogins()";
     try 
        {
            ObjectOutputStream sd = new ObjectOutputStream(new FileOutputStream(new File("resources/system.dll")));
            sd.writeObject(teller);
            sd.flush();
            sd.close();
        } 
        catch (FileNotFoundException ex)
        {
          ErrorLogger.ERRORQUEUE.println(MODULE+WHERE+ex.toString()+":"+ex.getLocalizedMessage());
        }
        catch (IOException ex)
        {
          ErrorLogger.ERRORQUEUE.println(MODULE+WHERE+ex.toString()+":"+ex.getLocalizedMessage());
        }
}
private void toggleLockAccount()
{
    int isLocked;
    String WHERE="toggleLockAccount():";
    try 
    {
        if(teller!=null&&teller.containsKey("is"+PRIVILEGE))
        {
          isLocked=Integer.parseInt(""+teller.get("is"+PRIVILEGE));
          char[] passwd=(char[])teller.get(PRIVILEGE);
        if(Arrays.equals(pass.getPassword(),passwd))
        {
            pass.setText("...........");
            ACCOUNTLOCK.setVisible(false);
           switch(isLocked)
           {
               case 0://unlocked
                   teller.put("is"+PRIVILEGE,"1");
                   updateLogins();
                   unlock.setText("Unlock");
                   JOptionPane.showMessageDialog(this,
                           PRIVILEGE+" IS LOCKED,YOU'LL HAVE TO ENTER YOUR PASSWORD,\nNEXT TIME YOU LOGIN TO THS ACCOUNT",
                           "ACCOUNT IS LOCKED",JOptionPane.INFORMATION_MESSAGE);
                   
                   break;
               case 1://Locked
                   teller.put("is"+PRIVILEGE,"0");
                   updateLogins();
                   unlock.setText("Lock Account");
                   JOptionPane.showMessageDialog(this,
                           PRIVILEGE+" IS UNLOCKED BUT THE INITIAL PASSWORD IS PRESERVED,"
                                   + "\nPLEASE NOTE THAT NO PASSWORD IS REQUIRED WHEN LOGIN IN TO AN ACCOUNT IN UNLOCKED STATE."
                                   + "\nTHIS EXPOSES THE ACCOUNT TO SECURITY RISKS.",
                           "ACCOUNT IS UNLOCKED",JOptionPane.WARNING_MESSAGE);
                   break;
               default:
                   JOptionPane.showMessageDialog(this,
                           "An Error Occured.No Changes Made.Please try again","ERROR OCCURRED",JOptionPane.ERROR_MESSAGE);
                   break;
           }
        }
        else
        {
        pass.setBorder(BorderFactory.createTitledBorder(null,"INCORRECT PASSWORD", TitledBorder.ABOVE_BOTTOM,TitledBorder.CENTER));
        Toolkit.getDefaultToolkit().beep();
        }
        }
    } 
    catch (NullPointerException ex)
    {
       HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
    }
    catch (HeadlessException ex)
    {
       HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
    }
    catch (NumberFormatException ex)
    {
       HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
    }
}
private void getIcons()
{
String WHERE="getIcons():";
try
{
rGen=new ImageIcon("resources/rGen.png");
calIcon=new ImageIcon("resources/calc.png");
calen=new ImageIcon("resources/calender.png");
fRep=new ImageIcon("resources/backup.png");
backupTool.setIcon(fRep);
calculatorTool.setIcon(calIcon);
calender.setIcon(calen);
reportGen.setIcon(rGen);
}
catch(Exception ex)
{
HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
}
}
public static int executeUpdate(String sql)
{
   Statement query1=null;
   Connection link1=null;
   String WHERE="executeUpdate(String):";
   try
   {
   Class.forName(HotelBiller.DB_Driver);
   link1=DriverManager.getConnection(HotelBiller.DB_URL,HotelBiller.userN,HotelBiller.pwd);
   query1=link1.createStatement();
   return (query1.executeUpdate(sql));
   }
    catch(ClassNotFoundException ex)
   {
   JOptionPane.showMessageDialog(null,"ERROR REGISTERING DRIVER \n"+ex.getLocalizedMessage());
   HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
   return -1;
   }
   catch(SQLException ex)
   {
   JOptionPane.showMessageDialog(null,"SQL EXception Occured\n"+ex.getMessage());
   HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
   return -1;
   }
   catch(Exception ex)
   {
   JOptionPane.showMessageDialog(null,"An EXception Occured\n"+ex.toString());
   HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
   return -1;
   }
   finally
   {
    try
    {
     query1.close();
     link1.close();
    }
    catch (Exception ex)
    {
    HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
    }
  }
}
public static ResultSet executeQuery(String sql)
{
   Statement query1=null;
   String WHERE="executeQuery(String):";
   Connection link1=null;
   try
   {
   Class.forName(HotelBiller.DB_Driver);
   link1=DriverManager.getConnection(HotelBiller.DB_URL,HotelBiller.userN,HotelBiller.pwd);
   query1=link1.createStatement();
   return (query1.executeQuery(sql));
   }
   catch(ClassNotFoundException e)
   {
   JOptionPane.showMessageDialog(null,"ERROR REGISTERING DRIVER");
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   return null;
   }
   catch(SQLException e)
   {
   JOptionPane.showMessageDialog(null,"SQL EXception Occured\n"+e.getMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   return null;
   }
   catch(NullPointerException e)
   {
   JOptionPane.showMessageDialog(null,"SQL EXception Occured\n"+e.getMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   return null;
   }
   finally
   {
    try
    {
     //query1.close();
     //link1.close();
    }
    catch (Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
  }
}
public static TableModel getModel(ResultSet rs)
{
    String WHERE="getModel(ResultSet):";
    DefaultTableModel tModel=new DefaultTableModel()
    {
        @Override
        public boolean isCellEditable(int row,int col){return false;}
    };
    int columns=0;
    try 
    {
        ResultSetMetaData metaData = rs.getMetaData();
        columns=metaData.getColumnCount();
        Object[] row=new String[columns];
        for(int y=1;y<=columns;y++)
        {
        String col=metaData.getColumnLabel(y);
        tModel.addColumn(col.toUpperCase());
        }
        while(rs.next())
        {
            for(int y=0;y<columns;y++)
            {
              row[y]=rs.getString(y+1);
            }
              tModel.addRow(row);
        }
    }
    catch (SQLException ex)
    {
       HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
       return (tModel);
    }
    catch (NullPointerException ex)
    {
       HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
       return (tModel);
    }
return (tModel);
}
public static void panelSwitched(JComponent from)
{
 String WHERE="panelSwitched():";
try
{
if(from.equals(tabs))
{
 centerPanel.remove(tabs);
 centerPanel.add(eventsCalender,BorderLayout.CENTER);
}
else if(from.equals(eventsCalender))
{
 centerPanel.remove(eventsCalender);
 centerPanel.add(tabs,BorderLayout.CENTER);
}
centerPanel.revalidate();
centerPanel.repaint();
}
catch(Exception e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
}
}
private void menuSelected(JMenuItem src)
{
String WHERE="menuSelected(JMenuItem):";
try
{
if(src.equals(exit))
{
System.exit(0);
}
else if(src.equals(backup))
{
backupTool.doClick();
}
else if(src.equals(calc))
{
calculatorTool.doClick();
}
else if(src.equals(report))
{
reportGen.doClick();
}
else if(src.equals(unlock))
{
pass.setBorder(BorderFactory.createTitledBorder(null,"ENTER CURRENT PASSWORD", TitledBorder.ABOVE_BOTTOM,TitledBorder.CENTER));
ACCOUNTLOCK.setVisible(true);
}
else if(src.equals(password))
{
securityPanel=new SecurityPanel();
securityPanel.setLocationRelativeTo(this);
securityPanel.setVisible(true);
}
}
catch(Exception e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
}
}
private void buttonClicked(JButton which)
{
 String WHERE="buttonClicked(JButton):";
try
{
 if(which.equals(reportGen))
{
reporter.setLocationRelativeTo(this);
reporter.initiateSession();
}
else if(which.equals(calculatorTool))
{
calculator.setVisible(true);
calculator.setLocationRelativeTo(this);
}
else if(which.equals(calender)&&!eventsCalender.isShowing())
{
panelSwitched(tabs);
}
else if(which.equals(toggle))
{
this.toggleLockAccount();
}
else if(which.equals(cancel))
{
ACCOUNTLOCK.setVisible(false);
pass.setText("........");
}
else if(which.equals(backupTool))
{
backupCreator.setLocationRelativeTo(this);
backupCreator.initiateOperation();
}
 }
 catch(Exception e)
 {
 HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
 }
}
private class EventsHandler implements ActionListener
{
        @Override
        public void actionPerformed(ActionEvent e) 
        {
          if(e.getSource() instanceof JButton)
          {
          JButton sos=(JButton) e.getSource();
          buttonClicked(sos);
          }
          else if(e.getSource() instanceof JMenuItem)
          {
          JMenuItem sos=(JMenuItem) e.getSource();
          menuSelected(sos);
          }
          else if(e.getSource().equals(pass))
          {
          toggleLockAccount();
          }
        }


}
}