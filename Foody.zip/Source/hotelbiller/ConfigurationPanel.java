package hotelbiller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author kamungeeric@gmail.com
 */
public class ConfigurationPanel{
    private static  JPasswordField password,stdPassword,adminPassword,confirmAdmin,confirmStd;
    private static JTextField username,database,IPAddress,userId,userKey;
    private static JButton save,reset,cancel,next,cancel1;
    private static JFrame form;
    private static final int width=500,height=500;
    public static Properties config,system;//=new Properties();
    private static JTextArea message;
    private static JTabbedPane tabber;
    private static JPanel userPanel,serverPanel;
    private static EventsHandler eventsHandler;
    private static final String MODULE="ConfigurationPanel:";
    private static final File DUMP=new File("resources/environment.dll"),
            events=new File("resources/system.dll");
    private static LoginManager guard;
    private static void getConfiguration()
    {
    form=new JFrame();
    form.setIconImage(HotelBiller.icon);
    tabber=new JTabbedPane();
    serverPanel=new JPanel();
    form.add(tabber);
    form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    form.setTitle("DEPLOYMENT SETTINGS");
    form.setBackground(MotherFrame.THEMECOLOR);
    form.setResizable(false);
    Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();
    form.setSize(width,height);
    Point p=new Point((screen.width-width)/2,(screen.height-height)/2);
    form.setLocation(p);
    serverPanel.setLayout(new BorderLayout());
    eventsHandler=new EventsHandler();
    next=new JButton("Next");
    next.addActionListener(eventsHandler);
    stdPassword=new JPasswordField();
    adminPassword=new JPasswordField();
    userId=new JTextField(10);
    userId.setBorder(BorderFactory.createTitledBorder("FOODY USER ID"));
    userKey=new JPasswordField(10);
    userKey.setBorder(BorderFactory.createTitledBorder("FOODY USER KEY"));
    password=new JPasswordField();
    password.setBorder(BorderFactory.createTitledBorder("DATABASE USER PASSWORD"));
    username=new JTextField(20);
    username.setBorder(BorderFactory.createTitledBorder("DATABASE USERNAME"));
    database=new JTextField(20);
    database.setBorder(BorderFactory.createTitledBorder("TARGET DATABASE NAME"));
    IPAddress=new JTextField(20);
    IPAddress.setBorder(BorderFactory.createTitledBorder("DATABASE HOST IP ADDRESS"));
    message=new JTextArea();
    message.setBorder(BorderFactory.createTitledBorder("PLEASE NOTE"));
    message.setWrapStyleWord(true);
    message.setLineWrap(true);
    message.setEditable(false);
    message.setBackground(MotherFrame.THEMECOLOR);
    message.setForeground(Color.WHITE);
    message.setText
        (
              "PLEASE NOTE THAT THIS IS A ONE TIME CONFIGURATION.ONCE COMPLETED SUCCESSFULLY,"
            + "YOU'LL NEVER BE PROMPTED AGAIN FOR THE REST OF RESTARTS AND REBOOTS."
            + "THESE CONFIGURATIONS ARE ONLY USABLE IF THE TARGET DATABSE IS OF TYPE MYSQL DBMS."
            + "THANK YOU FOR CHOOSING FOODY AND WELCOME."
        );
    reset=new JButton("Reset");
    cancel=new JButton("Cancel");
    JPanel buttons=new JPanel(),
           fields=new JPanel();
    fields.setLayout(new GridLayout(4,2));
    fields.setBackground(MotherFrame.THEMECOLOR);
    buttons.setBackground(MotherFrame.THEMECOLOR);
    //
    JTextField[] comps={IPAddress,database,userId,userKey,username,password};
    for(JTextField pb:comps)
    {
    fields.add(pb);
    pb.setPreferredSize(new Dimension(30,100));
    pb.setFont(new Font(Font.MONOSPACED,Font.BOLD,15));
    pb.setPreferredSize(new Dimension(300,30));
    pb.setHorizontalAlignment(SwingConstants.CENTER);
    }
    //
    JButton[] btns={reset,cancel,next};
    for(JButton jb: btns)
    {
    jb.setPreferredSize(new Dimension(100,30));
    jb.addActionListener(eventsHandler);
    buttons.add(jb);
    jb.setMnemonic(jb.getText().charAt(0));
    }
    //
    serverPanel.setBackground(MotherFrame.THEMECOLOR);
    serverPanel.add(message,BorderLayout.NORTH);
    serverPanel.add(fields,BorderLayout.CENTER);
    serverPanel.add(buttons,BorderLayout.SOUTH);
    tabber.addTab("SERVER CONFIGURATION",serverPanel);
    form.setVisible(true);
    }
    public static void configureAndStart()
    {
    String WHERE="setConfigured()";
    try
    {
    if(DUMP.exists())
    {
    ObjectInputStream in=new ObjectInputStream(new FileInputStream(DUMP));
    config=(Properties)in.readObject();
    if(getSetup())
    {
    proceedLogin();
    }
    else
    {
    getConfiguration();
    }
    }
    else
    {
    getConfiguration();
    }
    }
    catch(IOException ex)
    {
      //System.out.println("Error :"+ex.getMessage());
      ErrorLogger.ERRORQUEUE.println(MODULE+WHERE+ex.toString()+":"+ex.getLocalizedMessage());
    }
    catch (ClassNotFoundException ex) 
    {
       //System.out.println("Error :"+ex.toString());
       ErrorLogger.ERRORQUEUE.println(MODULE+WHERE+ex.toString()+":"+ex.getLocalizedMessage());
    }
    }
    private static void getUserPanel()
    {
    system=new Properties();
    userPanel=new JPanel();
    stdPassword=new JPasswordField();
    stdPassword.setName("STANDARD USER'S ACCOUNT PASSWORD");
    adminPassword=new JPasswordField();
    adminPassword.setName("ADMINISTRATOR'S ACCOUNT PASSWORD");
    confirmAdmin=new JPasswordField();
    confirmAdmin.setName("RE-ENTER ADMIN'S PASSWORD");
    confirmStd=new JPasswordField();
    confirmStd.setName("RE-ENTER STANDARD USER'S PASSWORD");
    JPanel passField=new JPanel();
    passField.setLayout(new GridLayout(4,1));
    JPasswordField[] pf={adminPassword,confirmAdmin,stdPassword,confirmStd};
    for(JPasswordField p:pf)
    {
        p.setEchoChar('.');
        p.setBorder(BorderFactory.createTitledBorder(p.getName()));
        p.setToolTipText(p.getName()+"\nWiil be used for initial login and\nIt can be changed later at will.");
        p.setFont(new Font(Font.MONOSPACED,Font.BOLD,15));
        p.setPreferredSize(new Dimension(300,30));
        p.setHorizontalAlignment(SwingConstants.CENTER);
        passField.add(p);
    }
    save=new JButton("Save");
    cancel1=new JButton("Cancel");
    JPanel btns=new JPanel();
    btns.setBackground(MotherFrame.THEMECOLOR);
    JButton[] bt={save,cancel1};
    for(JButton x:bt)
    {
    x.setPreferredSize(new Dimension(100,30));
    x.addActionListener(eventsHandler);
    x.setMnemonic(x.getText().charAt(0));
    btns.add(x);
    }
    JTextArea note=new JTextArea();
    note.setBorder(BorderFactory.createTitledBorder("NOTE"));
    note.setWrapStyleWord(true);
    note.setLineWrap(true);
    note.setEditable(false);
    note.setBackground(MotherFrame.THEMECOLOR);
    note.setForeground(Color.WHITE);
    note.setText("The passwords you set here will be used for the next login"
            + " and either of them can be changed later at user's discretion.\n");
    userPanel.setLayout(new BorderLayout());
    userPanel.setBorder(BorderFactory.createTitledBorder("USER ACCOUNTS CREDENTIALS)"));
    userPanel.add(new JScrollPane(note),BorderLayout.NORTH);
    userPanel.add(passField,BorderLayout.CENTER);
    userPanel.add(btns,BorderLayout.SOUTH);
    userPanel.setBackground(MotherFrame.THEMECOLOR);
    tabber.remove(0);
    tabber.addTab("SECURITY SETTINGS",userPanel);
    }
    private static boolean getSetup()
    {
        String WHERE="getSetup();";
        try
        {
        if(config.get("ip")!=null&&config.get("db")!=null
                &&config.get("user")!=null&&config.get("psd")!=null&&config.get("id")!=null)
        {
        HotelBiller.DB_URL="jdbc:mysql://"+config.get("ip")+"/"+config.get("db");
        HotelBiller.userN=""+config.get("user");
        MotherFrame.MY_ID=""+config.get("id");
        char[] ps=(char[])config.get("psd");
        String psd="";
        for(char c:ps){psd+=c;}
        HotelBiller.pwd=psd;//+
        return true;
        }
        else
        {
        return false;
        }
        }
        catch(Exception ex)
        {
        ErrorLogger.ERRORQUEUE.println(MODULE+WHERE+ex.toString());
        return false;
        }
    }
    private static void saveSetup()
    {
    String WHERE="saveSetup():";
    try
    {
    config=new Properties();
    if(DUMP.exists())
    {
     DUMP.setWritable(true);
     boolean deleted = DUMP.delete();
    }
    DUMP.createNewFile();
    config.put("ip",IPAddress.getText());
    config.put("user",username.getText());
    config.put("psd",password.getPassword());
    config.put("db",database.getText());
    config.put("id",userId.getText());
    ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(DUMP));
    out.writeObject(config);
    out.flush();
    out.close();
    
    }
    catch(IOException ex)
    {
      ErrorLogger.ERRORQUEUE.println(MODULE+WHERE+ex.toString()+":"+ex.getLocalizedMessage());
    }
    catch(Exception ex)
    {
      ErrorLogger.ERRORQUEUE.println(MODULE+WHERE+ex.toString()+":"+ex.getLocalizedMessage());
    }
    }
    private static void savePasswords()
    {
        String WHERE="savePasswords():";
        try 
        {
            system.put("ADMIN",adminPassword.getPassword());
            system.put("isADMIN","1");
            system.put("STANDARD",stdPassword.getPassword());
            system.put("isSTANDARD","1");
            ObjectOutputStream sd = new ObjectOutputStream(new FileOutputStream(events));
            sd.writeObject(system);
            sd.flush();
            System.out.println("Passwords saved");
            sd.close();
        } 
        catch (FileNotFoundException ex)
        {
          ErrorLogger.ERRORQUEUE.println(MODULE+WHERE+ex.toString()+":"+ex.getLocalizedMessage());
        }
        catch (IOException ex)
        {
         ErrorLogger.ERRORQUEUE.println(MODULE+WHERE+ex.toString()+":"+ex.getLocalizedMessage());
        }
    }
    private static void buttonClicked(JButton src)
    {
    if(src.equals(next))
    {
    if(!IPAddress.getText().equals("")&&!username.getText().equals("")&&!database.getText().equals("")&&!userId.getText().equals(""))
    {
        if(isDatabaseReady())
        {
          serverPanel.setEnabled(false);
          saveSetup();
          getUserPanel();
        }
        else
        {
        JOptionPane.showMessageDialog(form,"An error has occured connecting to database.\nPlease check the details and try again.",
                "ERROR CONNECTING TO DATABASE",JOptionPane.ERROR_MESSAGE);
        }
    }
    else
    {
    JOptionPane.showMessageDialog(form,"Some mandatory fields are empty.Please make sure to provide correct values for;\n"
            + "*Foody User Id,\n*Database Name and\nHost Address","MISSING DETAILS",JOptionPane.ERROR_MESSAGE);
    }
    }
    else if(src.equals(save))
    {
       allowLogin();
    }
    else if(src.equals(reset))
    {
    password.setText("");
    username.setText("");
    IPAddress.setText("");
    }
    else if(src.equals(cancel))
    {
    System.exit(0);
    }
    else if(src.equals(cancel1))
    {
    switch(JOptionPane.showConfirmDialog(form,"By canceling setup,all the previous settings will be reverted.\n"
            + "Sure to cancel setup?","SURE TO CANCEL SETUP?",JOptionPane.YES_NO_OPTION))
    {
        case JOptionPane.YES_OPTION:
            System.exit(0);
            break;
        case JOptionPane.NO_OPTION:
            break;
    }
    }
    }
    private static void allowLogin()
    {
   if(Arrays.equals(stdPassword.getPassword(),confirmStd.getPassword()))
   {
   if(Arrays.equals(adminPassword.getPassword(),confirmAdmin.getPassword()))
   {
   savePasswords();
   configureAndStart();
   }
   else
   {
   confirmAdmin.setBackground(Color.red);
   confirmAdmin.setBorder(BorderFactory.createTitledBorder("ADMIN'S PASSWORDS DO NOT MATCH"));
   confirmAdmin.requestFocusInWindow();
   }
   }
   else
   {
   confirmStd.setBackground(Color.red);
   confirmStd.setBorder(BorderFactory.createTitledBorder("USER'S PASSWORDS DO NOT MATCH"));
   confirmStd.requestFocusInWindow();
   }
   }
    private static void proceedLogin()
    {
        guard=new LoginManager();
        guard.lockSystem();
    }
    private static boolean isDatabaseReady()
    {
    String check="SELECT user_key FROM hotels WHERE hotel_id="+userId.getText(),WHERE="isDatabaseReady():";
     try
     {
         MotherFrame.MY_ID=userId.getText();
         HotelBiller.DB_URL="jdbc:mysql://"+IPAddress.getText()+"/"+database.getText();
         HotelBiller.userN=username.getText();
         char[] ps=password.getPassword();
         String psd="";
         for(char c:ps){psd+=c;}
         HotelBiller.pwd=psd;
            java.sql.ResultSet con=MotherFrame.executeQuery(check);
            if(con!=null&&con.first())
            {
                if(con.getString("user_key").equals(userKey.getText()))
                {
                return true;
                }
                else
                {
                return false;
                }
            }
            else
            {
                return false;
            }
     }
     catch(Exception ex)
     {
      ErrorLogger.ERRORQUEUE.println(MODULE+WHERE+ex.toString()+":"+ex.getLocalizedMessage());
      return false;  
     }
     }
    private static class EventsHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) 
        {
        if(e.getSource() instanceof JButton)
        {
        buttonClicked((JButton) e.getSource());
        }
        }
    }
}