/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package records;

import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.HeadlessException;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.filechooser.FileNameExtensionFilter;
import tabberView.OrdersPanel;
import tabberView.ReservationsPanel;

/**
 *
 * @author Eric
 */
public class Reporter extends JDialog{
private final JPanel documents,forOrders,forReservation,display;
private JPanel records;
private JButton cancel,cancel1,next,back,ok,word,excel,html,xml;
private final JCheckBox orders,meals,staff,reservations,join,byO,byR;
private final JComboBox ordersGroup,resGroup;
private final EventHandler eventHandler;
private final JTextField oMatch,rMatch;
private Icon selected,diselected;
private ImageIcon xls,htm,doc,xm;
private final Dimension size;
private final Desktop deskTop;
private static final String MODULE="Reporter:";

    public Reporter()
    {
    this.setModal(true);
    this.setIconImage(MotherFrame.icon);
    this.setTitle("Document Settings");
    this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    size=new Dimension(400,400);
    this.setSize(size);
    getIcons();
    //
    eventHandler=new EventHandler();
    //
    deskTop=Desktop.getDesktop();
    //
    Border textBorder=BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black),"Resembles..");
    oMatch=new JTextField();
    oMatch.setBorder(textBorder);
    rMatch=new JTextField();
    rMatch.setBorder(textBorder);
    //
    cancel=new JButton("Cancel");
    next=new JButton("Next");
    back=new JButton("Back");
    ok=new JButton("Generate");
    cancel1=new JButton("Cancel");
    cancel.addActionListener(eventHandler);
    back.addActionListener(eventHandler);
    next.addActionListener(eventHandler);
    ok.addActionListener(eventHandler);
    cancel1.addActionListener(eventHandler);
    //
    Border fieldBorder=BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black),"Where...");
    ordersGroup=new JComboBox(OrdersPanel.searchCriteria.getModel());
    ordersGroup.setBorder(fieldBorder);
    resGroup=new JComboBox();
    resGroup.setModel(ReservationsPanel.searchCriteria.getModel());
    resGroup.setBorder(fieldBorder);
    resGroup.addItemListener(eventHandler);
    resGroup.setAlignmentX(0);
    resGroup.setAlignmentY(0);
    //
    orders=new JCheckBox("Orders Report");
    orders.setSelectedIcon(selected);
    orders.setDisabledSelectedIcon(diselected);
    byO=new JCheckBox("Use Filter");
    byO.addItemListener(eventHandler);
    byO.setSelectedIcon(selected);
    byR=new JCheckBox("Use Filter");
    byR.addItemListener(eventHandler);
    meals=new JCheckBox("Meals Report");
    staff=new JCheckBox("Staff Report");
    reservations=new JCheckBox("Reservations Report");
    join=new JCheckBox("Join into One Document");
    orders.addItemListener(eventHandler);
    reservations.addItemListener(eventHandler);
    staff.addItemListener(eventHandler);
    join.addItemListener(eventHandler);
    //JPanels
    documents=new JPanel();
    records=new JPanel();
    records.setBackground(Color.WHITE);
    forOrders=new JPanel();
    forOrders.setBackground(Color.WHITE);
    forOrders.setLayout(new GridLayout(1,4));
    forOrders.setSize(this.getWidth(),40);
    forOrders.add(orders);
    forOrders.add(byO);
    forOrders.add(ordersGroup);
    forOrders.add(oMatch);
    forReservation=new JPanel();
    forReservation.setBackground(Color.WHITE);
    forReservation.setSize(this.getWidth(),40);
    forReservation.setLayout(new GridLayout(1,4));
    forReservation.add(reservations);
    forReservation.add(byR);
    forReservation.add(resGroup);
    forReservation.add(rMatch);
    records.setLayout(new GridLayout(6,1));
    records.add(forOrders);
    records.add(forReservation);
    meals.setBackground(Color.WHITE);
    records.add(meals);
    staff.setBackground(Color.WHITE);
    records.add(staff);
    join.setBackground(Color.WHITE);
    join.setToolTipText("All the reports will be contained in one document");
    records.add(join);
    JPanel p=new JPanel();
    p.add(cancel);
    p.add(next);
    records.add(p);
    display=records;
    this.getContentPane().add(display,BorderLayout.CENTER);
    this.readyDocPanel();
    }
    private void buttonClicked(JButton source)
    {
    if(source.equals(next))
    {
    this.getContentPane().removeAll();    
    this.getContentPane().add(documents);
    this.getContentPane().validate();
    this.getContentPane().repaint();
    }
    else if(source.equals(back))
    {
    this.getContentPane().removeAll();    
    this.getContentPane().add(records);
    this.getContentPane().validate();
    this.getContentPane().repaint();
    }
    else if(source.equals(cancel))
    {
    this.setVisible(false);
    }
    else if(source.equals(cancel1))
    {
    this.setVisible(false);
    }
    else if(source.equals(word))
    {
    generateReport(".doc");
    }
    else if(source.equals(excel))
    {
    generateReport(".xls");
    }
    else if(source.equals(html))
    {
    generateReport(".html");
    }
    else if(source.equals(xml))
    {
    generateReport(".xml");
    }
    }
    private void comboBoxChanged(JComboBox source,int state)
    {
    switch(state)
    {
        case ItemEvent.DESELECTED:
            if(source.equals(ordersGroup))
            {

            }
            break;
        case ItemEvent.SELECTED:
            if(source.equals(ordersGroup))
            {

            }
            break;
    }
    }
    public void initiateSession()
    {
    join.setSelected(true);
    byO.setSelected(false);
    byR.setSelected(false);
    orders.setSelected(true);
    reservations.setSelected(true);
    this.getContentPane().removeAll();    
    this.getContentPane().add(records);
    this.getContentPane().validate();
    this.getContentPane().repaint();
    this.setVisible(true);
    }
    private void getIcons()
    {
    doc=new ImageIcon("resources/doc.png");
    xls=new ImageIcon("resources/excel.png");
    htm=new ImageIcon("resources/html.png");
    xm=new ImageIcon("resources/xml.png");
    }
    private void checkBoxChanged(JCheckBox source,int state)
    {
    switch(state)
    {
        case ItemEvent.DESELECTED:
            if(source.equals(join))
            {
            join.setToolTipText("Each report will be contained in one seperate file");
            }
            else if(source.equals(orders))
            {
            byO.setEnabled(false);
            ordersGroup.setEnabled(false);
            byO.setSelected(false);
            }
            else if(source.equals(reservations))
            {
            byR.setEnabled(false);
            resGroup.setEnabled(false);
            byR.setSelected(false);
            }
            else if(source.equals(byO))
            {
            oMatch.setEnabled(false);
            ordersGroup.setEnabled(false);
            }
            else if(source.equals(byR))
            {
            rMatch.setEnabled(false);
            resGroup.setEnabled(false);
            }
            break;
        case ItemEvent.SELECTED:
            if(source.equals(join))
            {
            join.setToolTipText("All the reports will be contained in one common file");
            }
            else if(source.equals(orders))
            {
            byO.setSelected(true);
            byO.setEnabled(true);
            }
            else if(source.equals(reservations))
            {
            byR.setSelected(true);
            byR.setEnabled(true);
            }
            else if(source.equals(byR))
            {
            rMatch.setEnabled(true);
            resGroup.setEnabled(true);
            }
            else if(source.equals(byO))
            {
            oMatch.setEnabled(true);
            ordersGroup.setEnabled(true);
            }
            break;
    }
    }
    private void readyDocPanel()
    {
    documents.setLayout(new GridLayout(5,1));
    Font bF=new Font(Font.SANS_SERIF,Font.HANGING_BASELINE,20);
    word=new JButton("Ms Word Document",doc);
    word.setFont(bF);
    word.setIconTextGap(90);
    word.setForeground(Color.BLUE);
    excel=new JButton("Ms Excel WorkSheet",xls);
    excel.setFont(bF);
    excel.setForeground(Color.GREEN);
    excel.setIconTextGap(50);
    xml=new JButton("XML Document",xm);
    xml.setFont(bF);
    xml.setForeground(Color.green);
    xml.setIconTextGap(90);
    html=new JButton("Web page Document",htm);
    html.setFont(bF);
    html.setForeground(Color.blue);
    html.setIconTextGap(50);
    word.addActionListener(eventHandler);
    excel.addActionListener(eventHandler);
    xml.addActionListener(eventHandler);
    html.addActionListener(eventHandler);
    documents.add(word);
    documents.add(excel);
    documents.add(html);
    documents.add(xml);
    JPanel p=new JPanel();
    p.add(back);
    p.add(cancel1);
    documents.add(p);
    }
    private void generateReport(String ext)
    {
    JFileChooser fileChooser=new JFileChooser();
    fileChooser.setAcceptAllFileFilterUsed(false);
    if(join.isSelected())
    {
    fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    if(ext.equalsIgnoreCase(".xml"))
    {fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("XML Files","xml"));}
    else if(ext.equalsIgnoreCase(".xls"))
    {fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Excel Worksheet Files","xls"));}
    else if(ext.equalsIgnoreCase(".doc"))
    {fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Word Document","doc","docx"));}
    else if(ext.equalsIgnoreCase(".html"))
    {fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Web Document","html","htm"));}
    fileChooser.setSelectedFile(new File("Foody Report at "+new Date().toString().substring(0,16).replace(':', '-')));
    }
    else
    {
    fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    }
    fileChooser.setForeground(Color.orange);
    switch(fileChooser.showSaveDialog(this))
    {
        case JFileChooser.APPROVE_OPTION:
            File file=fileChooser.getSelectedFile();
            if(ext.equals(".xml"))
            {
            createXMLFiles(new File(file.getAbsolutePath()));
            }
            else
            {
            createDocFile(new File(file.getAbsolutePath()),ext);
            }
            this.setVisible(false);
            break;
        case JFileChooser.CANCEL_OPTION:
            break;
    }
    }
    private void createDocFile(File f,String ext)
    {
    String WHERE="createDocFile():";
    String header="<!DOCTYPE html><html><head><title>FOODY REPORT AS OF "+new Date().toString().toUpperCase()+"</title>"
            +"\n<style type='text/css'>"
            +"\n.table{cellpadding:10px; cellspacing:2px; text-align:left; width:100%;"
            +" border: 1px solid black; align:center; border-collapse:collapse; overflow-x:auto;}"
            +"\n.fields{text-align:center; background-color:#4CAF50; border:1px solid black;}"
            +"\n.footer{text-align:center; cellpadding:10px; background-color:#4CAF50;}"
            +"\n.head{background-color:#4CAF50; color:white; border-collapse:collapse; "
            + "border:1px solid black; text-align:center;}"
            +"\n</style></head><body>",
            footer="</body>\n<html>";
    if(join.isSelected())
    {
    try
    {
    File file=new File(f.getAbsolutePath()+ext);
    if(!file.exists())
    {
    boolean done=file.createNewFile();
    }
    PrintStream writer=new PrintStream(file);
    writer.println(header);
    if(orders.isSelected())
    {
    createOrdersFile(writer);
    }
    if(meals.isSelected())
    {
    this.createMealsFile(writer);
    }
    if(staff.isSelected())
    {
    this.createStaffsFile(writer);
    }
    if(reservations.isSelected())
    {
    this.createReservationsFile(writer);
    }
    writer.println(footer);
    writer.flush();
    writer.close();
    int opt=JOptionPane.showConfirmDialog(this,"Document created at \n"+file.getPath()+"\n Do you want to Open the file?","Open File?",JOptionPane.YES_NO_OPTION);
    switch(opt)
    {
        case JOptionPane.YES_OPTION:
        deskTop.open(file);
            break;
        case JOptionPane.NO_OPTION:
            break;
    }
    }
    catch(IOException e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    else//user desires seperate file reports
    {
    File file=new File(f.getAbsolutePath());
    try
    {
    if(orders.isEnabled()&&orders.isSelected())
    {
    String name=file.getAbsolutePath()+'\\'+"Orders Report as at "+new Date().toString().substring(0,16).replace(':', '-')+ext;
    File target=new File(name);
    if(!target.exists())
    {
    boolean d=target.createNewFile();
    }
    PrintStream toOrders=new PrintStream(target);
    toOrders.println(header);
    createOrdersFile(toOrders);
    toOrders.print(footer);
    toOrders.flush();
    toOrders.close();
    }
    if(staff.isEnabled()&&staff.isSelected())
    {
    String name=file.getAbsolutePath()+'\\'+"Staff Register as at "+new Date().toString().substring(0,16).replace(':', '-')+ext;
    File target=new File(name);
    if(!target.exists())
    {
    boolean d=target.createNewFile();
    }
    PrintStream toStaff=new PrintStream(target);
    toStaff.println(header);
    createStaffsFile(toStaff);
    toStaff.print(footer);
    toStaff.flush();
    toStaff.close();
    }
    if(meals.isEnabled()&&meals.isSelected())
    {
    String name=file.getAbsolutePath()+'\\'+"Meals List as at "+new Date().toString().substring(0,16).replace(':', '-')+ext;
    File target=new File(name);
    if(!target.exists())
    {
    boolean d=target.createNewFile();
    }
    PrintStream toMeals=new PrintStream(target);
    toMeals.println(header);
    createMealsFile(toMeals);
    toMeals.print(footer);
    toMeals.flush();
    toMeals.close();
    }
    if(reservations.isEnabled()&&reservations.isSelected())
    {
    String name=file.getAbsolutePath()+'\\'+"Reseravtions Records as at "+new Date().toString().substring(0,16).replace(':', '-')+ext;
    File target=new File(name);
    if(!target.exists())
    {
    boolean d=target.createNewFile();
    }
    PrintStream toRes=new PrintStream(target);
    toRes.println(header);
    createReservationsFile(toRes);
    toRes.print(footer);
    toRes.flush();
    toRes.close();
    }
    int opt=JOptionPane.showConfirmDialog(this,"Documents created in \n"+file.getAbsolutePath()+"\n Do you want to Open the folder?","Open Folder?",JOptionPane.YES_NO_OPTION);
    switch(opt)
    {
        case JOptionPane.YES_OPTION:
        deskTop.open(file);
            break;
        case JOptionPane.NO_OPTION:
            break;
    }
    }
    catch(IOException e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    } 
    catch (HeadlessException e) 
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    catch (Exception e) 
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    }
    private void createXMLFiles(File f)
    {
     String WHERE="createXMLFiles():";
    if(join.isSelected())
    {
    File file=new File(f.getAbsolutePath()+".xml");
    try
    {
    if(!file.exists())
    {
    boolean done=file.createNewFile();
    }
    PrintStream writer=new PrintStream(file);
    writer.println("<?xml version='1.0' encoding='utf-8' standalone='no'?>");
    writer.println("<FOODYRECORDS>");
    if(orders.isEnabled()&&orders.isSelected())
    {
    writer.println("<ORDERS>");
    exportOrdersToXML(writer);
    writer.println("</ORDERS>");
    }
    if(reservations.isEnabled()&&reservations.isSelected())
    {
    writer.println("<RESERVATIONS>");
    exportReservationsToXML(writer);
    writer.println("</RESERVATIONS>");
    }
    if(staff.isEnabled()&&staff.isSelected())
    {
    writer.println("<STAFF>");
    exportStaffToXML(writer);
    writer.println("</STAFF>");
    }
    if(meals.isEnabled()&&meals.isSelected())
    {
    writer.println("<MEALS>");
    exportMealsToXML(writer);
    writer.println("</MEALS>");
    }
    writer.println("</FOODYRECORDS>");
    writer.flush();
    writer.close(); 
    int opt=JOptionPane.showConfirmDialog(this,"Document created at \n"+file.getAbsolutePath()+"\n Do you want to Open the file?","Open File?",JOptionPane.YES_NO_OPTION);
    switch(opt)
    {
        case JOptionPane.YES_OPTION:
        deskTop.open(file);
            break;
        case JOptionPane.NO_OPTION:
            break;
    }
    }
    catch(IOException e)
     {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
     }   
    catch (HeadlessException e) 
    {
         HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    catch (Exception e) 
    {
         HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    else//user wants sepearate files
    {
    try
    {
    if(orders.isEnabled()&&orders.isSelected())
    {
    String name=f.getAbsolutePath()+'\\'+"Orders Report as at "+new Date().toString().substring(0,16).replace(':', '-')+".xml";
    File target=new File(name);
    if(!target.exists())
    {
    boolean d=target.createNewFile();
    }
    PrintStream toOrders=new PrintStream(target);
    toOrders.println("<?xml version='1.0' encoding='utf-8' standalone='no'?>");
    toOrders.println("<ORDERS>");
    exportOrdersToXML(toOrders);
    toOrders.println("</ORDERS>");
    toOrders.flush();
    toOrders.close();
    }
    if(reservations.isEnabled()&&reservations.isSelected())
    {
    String name=f.getPath()+'\\'+"Reservations Report as at "+new Date().toString().substring(0,16).replace(':', '-')+".xml";
    File target=new File(name);
    if(!target.exists())
    {
    boolean d=target.createNewFile();
    }
    PrintStream toRes=new PrintStream(target);
    toRes.println("<?xml version='1.0' encoding='utf-8' standalone='no'?>");
    toRes.println("<RESERVATIONS>");
    exportReservationsToXML(toRes);
    toRes.println("</RESERVATIONS>");
    toRes.flush();
    toRes.close();
    }
    if(staff.isEnabled()&&staff.isSelected())
    {
    String name=f.getPath()+'\\'+"Staff Register as at "+new Date().toString().substring(0,16).replace(':', '-')+".xml";
    File target=new File(name);
    if(!target.exists())
    {
    boolean d=target.createNewFile();
    }
    PrintStream toStaff=new PrintStream(target);
    toStaff.println("<?xml version='1.0' encoding='utf-8' standalone='no'?>");
    toStaff.println("<STAFF>");
    exportStaffToXML(toStaff);
    toStaff.println("</STAFF>");
    toStaff.flush();
    toStaff.close();
    }
    if(meals.isEnabled()&&meals.isSelected())
    {
    String name=f.getPath()+'\\'+"Foods List as at "+new Date().toString().substring(0,16).replace(':', '-')+".xml";
    File target=new File(name);
    if(!target.exists())
    {
    boolean d=target.createNewFile();
    }
    PrintStream toMeals=new PrintStream(target);
    toMeals.println("<?xml version='1.0' encoding='utf-8' standalone='no'?>");
    toMeals.println("<MEALS>");
    exportMealsToXML(toMeals);
    toMeals.println("</MEALS>");
    toMeals.flush();
    toMeals.close();
    }
    int opt=JOptionPane.showConfirmDialog(this,"Documents created in \n"+f.getAbsolutePath()+"\n Do you want to Open the folder?","Open Folder?",JOptionPane.YES_NO_OPTION);
    switch(opt)
    {
        case JOptionPane.YES_OPTION:
        deskTop.open(f);
            break;
        case JOptionPane.NO_OPTION:
            break;
    }
    }
    catch(HeadlessException e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    catch(IOException e) 
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    catch(Exception e) 
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }

    }
    }
    private void createOrdersFile(PrintStream pw) 
    {
        String query="SELECT order_id,list,bill,duly_paid,staff_id,date FROM ORDERS WHERE hotel_id="+MotherFrame.MY_ID,WHERE="createOrdersFile(PrintStream):";
        if(byO.isEnabled()&&byO.isSelected())
        {
        query="SELECT order_id,list,bill,duly_paid,staff_id,date FROM ORDERS WHERE "+ordersGroup.getSelectedItem()+" LIKE '"+oMatch.getText()+"'";
        }
        pw.println("<br /><hr><br />");
        pw.println("<table title='orders report' class='table' border='1'>");
        pw.println("<tr class='head'><td colspan='6' align='center'>ORDERS REPORT AS AT "+new Date().toString().toUpperCase()+"</td></tr>");
        pw.println("<tr class='head'>");
        pw.println("<th>ID</th><th>LIST</th><th>BILL</th><th>DULY PAID</th><th>STAFF</th><th>DATE</th>");
        pw.println("</tr>");
        try
        {
            ResultSet ors=MotherFrame.executeQuery(query);
            if(ors!=null)
            {
                while(ors.next())
                {
                 pw.println("<tr>");
                 pw.println("<td text-align: center;>"+ors.getString("order_id")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("list")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("bill")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("duly_paid")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("staff_id")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("date")+"</td>");
                 pw.println("</tr>");
                 pw.flush();
                }

            }
        }
        catch (SQLException e)
        {
          HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
        }
         pw.println("</table>");
    }
    private void createMealsFile(PrintStream pw) 
    {
        String WHERE="createMealsFiles(PrintStream):";
        pw.println("<br /><hr><br />");
        pw.print("<table title='orders report' class='table' border='1'>");
        pw.print("<tr class='head'><td colspan='6' align='center'>FOODY MENU AS AT "+new Date().toString().toUpperCase()+"</td></tr>");
        pw.print("<tr class='head'>");
        pw.print("<th>ID</th><th>NAME</th><th>CATEGORY</th><th>UNIT OF SALE</th><th>COST</th><th>AVAILABLE</th>");
        pw.print("</tr>");
        try 
        {
            ResultSet ors=MotherFrame.executeQuery("SELECT meal_id,meal_name,category,unit,cost,available FROM meals WHERE hotel_id="+MotherFrame.MY_ID);
            if(ors!=null)
            {
                while(ors.next())
                {
                 pw.print("<tr>");
                 pw.print("<td text-align: center;>"+ors.getString("meal_id")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("meal_name")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("category")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("unit")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("cost")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("available")+"</td>");
                 pw.print("</tr>");
                 pw.flush();
                }

            }
        }
        catch (SQLException e)
        {
          HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
        }
        catch (Exception e)
        {
          HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
        }
         pw.print("</table>");
    }
    private void createReservationsFile(PrintStream pw) 
    {   
        String query="SELECT recno,client,facility,from_time,duration,client_id,mobile,prepayment,cost FROM reservation WHERE hotel_id="+MotherFrame.MY_ID,WHERE="createReservationsFile(PrintStream):";
        if(byR.isEnabled()&&byR.isSelected())
        {
        query="SELECT recno,client,facility,from_time,duration,client_id,mobile,prepayment,cost FROM reservation WHERE "+resGroup.getSelectedItem()+" LIKE '"+rMatch.getText()+"' AND hotel_id="+MotherFrame.MY_ID;
        }
        pw.println("<br /><hr><br />");
        pw.println("<table title='orders report' class='table' border='1'>");
        pw.println("<tr class='head'><td colspan='10' align='center'>RESERVATION REPORT AS AT "+new Date().toString().toUpperCase()+"</td></tr>");
        pw.println("<tr class='head'>");
        pw.print("<th>REC NO.</th><th>CLIENT</th><th>MOBILE</th><th>FACILITY</th><th>AS FROM</th>");
        pw.print("<th>DURATION(HOURS)</th><th>ID NO</th><th>PREPAYMENT (KSh)</th><th>TOTAL COST(KSh)</th><th>DUE BALANCE(KSh)</th></th>");
        pw.println("</tr>");
        try
        {
            ResultSet ors=MotherFrame.executeQuery(query);
            if(ors!=null)
            {
                while(ors.next())
                {
                 pw.println("<tr>");
                 pw.println("<td text-align: center;>"+ors.getString("recno")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("client")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("mobile")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("facility")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("from_time")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("duration")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("client_id")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("prepayment")+"</td>");
                 pw.println("<td text-align: center;>"+ors.getString("cost")+"</td>");
                 pw.println("<td text-align: center;> "+(ors.getFloat("cost")-ors.getFloat("prepayment"))+"</td>");
                 pw.println("</tr>");
                 pw.flush();
                }
            ors.close();
            }
        }
        catch (SQLException e)
        {
        HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
        }
        catch (Exception e)
        {
          HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
        }
         pw.println("</table>");
    }
    private void createStaffsFile(PrintStream pw) 
    {
        String WHERE="createStaffsFile(PrintStream):";
        pw.println("<br /><hr><br />");
        pw.print("<table title='orders report' class='table' border='1'>");
        pw.print("<tr class='head'><td colspan='7' align='center'>STAFF REGISTER AS AT "+new Date().toString().toUpperCase()+"</td></tr>");
        pw.print("<tr class='head'>");
        pw.print("<th>NAME</th><th>DESIGNATION</th><th>REG' NUMBER</th><th>RATING</th><th>AGE</th><th>ID</th><th>ON DUTY</th>");
        pw.print("</tr>");
        try
        {
            ResultSet ors=MotherFrame.executeQuery("SELECT * FROM staff WHERE hotel_id="+MotherFrame.MY_ID);
            if(ors!=null)
            {
                while(ors.next())
                { 
                 pw.print("<tr>");
                 pw.print("<td text-align: center;>"+ors.getString("name")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("designation")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("regno")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("rating")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("age")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("staff_id")+"</td>");
                 pw.print("<td text-align: center;>"+ors.getString("on_duty")+"</td>");
                 pw.print("</tr>");
                 pw.flush();
                }

            }
        }
        catch (SQLException e)
        {
         HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
        }
        catch (Exception e)
        {
         HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
        }
         pw.print("</table>");
    }
    private void exportOrdersToXML(PrintStream pw) 
    {
    String query="SELECT * FROM ORDERS  WHERE hotel_id="+MotherFrame.MY_ID,WHERE="exportOrdersToXML(printStream):";
    if(byO.isEnabled()&&byO.isSelected())
    {
    query="SELECT * FROM ORDERS WHERE "+ordersGroup.getSelectedItem()+" LIKE '"+oMatch.getText()+"' AND hotel_id="+MotherFrame.MY_ID;
    }
    try
    {
        ResultSet ors=MotherFrame.executeQuery(query);
        if(ors!=null)
        {
            while(ors.next())
            {
             pw.println("<order ");
             pw.print(" id='"+ors.getString("order_id")+"'");
             pw.print(" list='"+ors.getString("list")+"'");
             pw.print(" bill='"+ors.getString("bill")+"'");
             pw.print(" dulypaid='"+ors.getString("duly_paid")+"'");
             pw.print(" waiter='"+ors.getString("staff_id")+"'");
             pw.print(" date='"+ors.getString("date")+"'");
             pw.print(" />");
             pw.flush();
            }
            ors.close();
        }
    }
    catch (SQLException e)
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    catch (Exception e)
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    private void exportReservationsToXML(PrintStream pw) 
    {
    String query="SELECT * FROM RESERVATION WHERE hotel_id="+MotherFrame.MY_ID,WHERE="exportReservationsToXML(PrintStream):";
    if(byR.isEnabled()&&byR.isSelected())
    {
    query="SELECT * FROM RESERVATION WHERE "+resGroup.getSelectedItem()+" LIKE '"+rMatch.getText()+"' AND hotel_id="+MotherFrame.MY_ID;
    }
    try
    {
        ResultSet ors=MotherFrame.executeQuery(query);
        if(ors!=null)
        {
            while(ors.next())
            {
             pw.println("<reseravtion ");
             pw.print(" recno='"+ors.getString("recno")+"' ");
             pw.print(" client='"+ors.getString("client")+"'");
             pw.print(" mobile='"+ors.getString("mobile")+"'");
             pw.print(" facility='"+ors.getString("facility")+"'");
             pw.print(" fromtime='"+ors.getString("from_time")+"'");
             pw.print(" duartion='"+ors.getString("duration")+"'");
             pw.print(" id='"+ors.getString("client_id")+"'");
             pw.print(" prepayment='"+ors.getString("prepayment")+"'");
             pw.print(" cost='"+ors.getString("cost")+"'");
             pw.print(" />");
             pw.flush();
            }
        ors.close();
        }
    }
    catch (SQLException e)
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    catch (Exception e)
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    private void exportStaffToXML(PrintStream pw) 
    {
    String WHERE="exportStaffToXML(PrintStream():";
    try
    {
        ResultSet ors=MotherFrame.executeQuery("SELECT * FROM STAFF WHERE hotel_id="+MotherFrame.MY_ID);
        if(ors!=null)
        {
            while(ors.next())
            {
             pw.println("<staff");
             pw.print(" name='"+ors.getString("name")+"'");
             pw.print(" designation='"+ors.getString("designation")+"'");
             pw.print(" regno='"+ors.getString("regno")+"'");
             pw.print(" rating='"+ors.getString("rating")+"'");
             pw.print(" age='"+ors.getString("age")+"'");
             pw.print(" id='"+ors.getString("staff_id")+"'");
             pw.print(" onduty='"+ors.getString("on_duty")+"'");
             pw.print(" />");
             pw.flush();
            }
            ors.close();
        }
    }
    catch (SQLException e)
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
     catch (Exception e)
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    private void exportMealsToXML(PrintStream pw) 
    {
    String WHERE="exportMealsToXML(PrintStream):";
    try 
    {
        ResultSet ors=MotherFrame.executeQuery("SELECT * FROM meals WHERE hotel_id="+MotherFrame.MY_ID);
        if(ors!=null)
        {
            while(ors.next())
            {
             pw.print("<meal ");
             pw.print(" meal_id='"+ors.getString("meal_id")+"'");
             pw.print(" meal_name='"+ors.getString("meal_name")+"'");
             pw.print(" category='"+ors.getString("category")+"'");
             pw.print(" unit='"+ors.getString("unit")+"'");
             pw.print(" cost='"+ors.getString("cost")+"'");
             pw.print(" available='"+ors.getString("available")+"'");
             pw.print(" />");
             pw.flush();
            }
            ors.close();
        }
    }
    catch (SQLException e)
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    private class EventHandler implements ActionListener,ItemListener
    {

            @Override
            public void actionPerformed(ActionEvent e) 
            {
             Object sos=e.getSource();
             if(sos instanceof JButton)
             {
             JButton source=(JButton) sos;
             buttonClicked(source);
             }
            }
            @Override
            public void itemStateChanged(ItemEvent e) 
            {
             if(e.getSource() instanceof JComboBox)
             {
             JComboBox sos=(JComboBox) e.getSource();
             comboBoxChanged(sos,e.getStateChange());
             }
             else if(e.getSource() instanceof JCheckBox)
             {
             JCheckBox sos=(JCheckBox) e.getSource();
             checkBoxChanged(sos,e.getStateChange());
             }
            }
        }
}