/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package records;

import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * @author Eric Kamunge
 */
public class BackupCreator extends JDialog{
    private final JPanel backerUp,restorer;
    private final JCheckBox forOrders,forEvents,forMeals,forRes,forStaff;
    private final JCheckBox reOrders,reEvents,reMeals,reRes,reStaff;
    private final JTabbedPane option;
    private Properties BACKUPS;
    private final JTextField sourcePath;
    private final JTextArea fileInfo;
    private final JButton create,cancel,restore,back,browse;
    private final EventsHandler eventsHandler;
    private static final String MODULE="BackupCreator:";
    public BackupCreator()
    {
    this.setModal(true);
    this.setIconImage(MotherFrame.icon);
    this.setSize(400,400);
    this.setResizable(false);
    this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    this.setTitle("Records Backup");
    eventsHandler=new EventsHandler();
    BACKUPS=new Properties();
    forOrders=new JCheckBox("Backup Orders");
    forEvents=new JCheckBox("Backup Events");
    forMeals=new JCheckBox("Backup Meals");
    forRes=new JCheckBox("Backup Reservations");
    forStaff=new JCheckBox("Backup Staff");
    JPanel checks=new JPanel(),
            holder=new JPanel();
    checks.setLayout(new GridLayout(3,2));
    checks.setBorder(BorderFactory.createTitledBorder("Select Recods To Backup"));
    JCheckBox[] cks={forOrders,forEvents,forMeals,forRes,forStaff};
    for(JCheckBox cx: cks)
    {
    checks.add(cx);
    cx.addItemListener(eventsHandler);
    }
    fileInfo=new JTextArea("Choose a backup file to restore from");
    fileInfo.setWrapStyleWord(true);
    fileInfo.setEditable(false);
    fileInfo.setBorder(BorderFactory.createTitledBorder("File Info"));
    JPanel area=new JPanel();
    area.setLayout(new BorderLayout());
    area.add(fileInfo,BorderLayout.CENTER);
    holder.setLayout(new GridLayout(2,1));
    holder.add(new JScrollPane(fileInfo));
    sourcePath=new JTextField();
    sourcePath.setEditable(false);
    browse=new JButton("Browse");
    browse.addActionListener(eventsHandler);
    create=new JButton("Create");
    create.addActionListener(eventsHandler);
    cancel=new JButton("Cancel");
    cancel.addActionListener(eventsHandler);
    JPanel btn=new JPanel();
    JPanel source=new JPanel();
    source.setBorder(BorderFactory.createTitledBorder("Choose backup File"));
    source.setLayout(new BorderLayout());
    source.add(sourcePath,BorderLayout.CENTER);
    source.add(browse,BorderLayout.EAST);
    btn.add(cancel);
    btn.add(create);
    reOrders=new JCheckBox("Restore Orders");
    reEvents=new JCheckBox("Restore Events");
    reMeals=new JCheckBox("Restore Meals");
    reStaff=new JCheckBox("Restore Staff register");
    reRes=new JCheckBox("Restore Reservations");
    JPanel resPanel=new JPanel();
    JCheckBox[] cbs={reOrders,reEvents,reMeals,reRes,reStaff};
    for(JCheckBox c: cbs)
    {
        resPanel.add(c);
        c.addItemListener(eventsHandler);
        c.setEnabled(false);
    }
    resPanel.setLayout(new GridLayout(3,2));
    resPanel.setBorder(BorderFactory.createTitledBorder("Select Restore Options"));
    holder.add(resPanel);
    backerUp=new JPanel();
    backerUp.setLayout(new BorderLayout());
    backerUp.add(checks,BorderLayout.CENTER);
    backerUp.add(btn,BorderLayout.SOUTH);
    restore=new JButton("Restore");
    restore.addActionListener(eventsHandler);
    back=new JButton("Cancel");
    back.addActionListener(eventsHandler);
    JPanel rbtn=new JPanel();
    rbtn.add(back);
    rbtn.add(restore);
    restorer=new JPanel();
    restorer.setLayout(new BorderLayout());
    restorer.add(source,BorderLayout.NORTH);
    restorer.add(holder,BorderLayout.CENTER);
    restorer.add(rbtn,BorderLayout.SOUTH);
    restorer.setEnabled(false);
    option=new JTabbedPane();
    option.addTab("Create Backup",backerUp);
    if(MotherFrame.PRIVILEGE.equals("ADMIN"))
    {
    option.addTab("Restore Backup",restorer);
    }
    this.getContentPane().add(option);
    }
    public void beginBackup()
    {
    if(forOrders.isSelected()||forRes.isSelected()||forMeals.isSelected()||forEvents.isSelected()||forStaff.isSelected())
    {
    JFileChooser file=new JFileChooser();
    file.setAcceptAllFileFilterUsed(false);
    file.addChoosableFileFilter(new FileNameExtensionFilter("Foody Backup Files","fbup"));
    String fName="Backup "+new Date().toString().substring(0,16).replace(':',' ');
    file.setFileSelectionMode(JFileChooser.FILES_ONLY);
    file.setSelectedFile(new File(fName));
    File target;
    
    switch(file.showSaveDialog(create))
    {
        case JFileChooser.APPROVE_OPTION:
           target=file.getSelectedFile();
           createBackup(target);
            break;
        case JFileChooser.CANCEL_OPTION:
            
            break;
    }
    }
    else
    {
     JOptionPane.showMessageDialog(this,"None of the Records is Selected");
    }
    }
    private void buttonClicked(JButton src)
    {
    if(src.equals(create))
    {
    beginBackup();
    }
    else if(src.equals(cancel)||src.equals(back))
    {
    this.setVisible(false);
    }
    else if(src.equals(restore))
    {
    beginRestoration();
    }
    else if(src.equals(browse))
    {
    pickFileanValidate();
    }
    }
    private void checkBoxStateChanged(JCheckBox sc)
    {
    if(!reOrders.isSelected()&&!reMeals.isSelected()&&!reStaff.isSelected()&&!reRes.isSelected()&&!reEvents.isSelected())
     {
     restore.setEnabled(false);
     }
    else
    {
    restore.setEnabled(true);
    }
    if(forOrders.isSelected()||forMeals.isSelected()||forStaff.isSelected()||forRes.isSelected()||forEvents.isSelected())
    {
     create.setEnabled(true);
    }
    else
    {
    create.setEnabled(false);
    }
    }
    private void groomRestoreOptions()
    {
    fileInfo.setText("CREATION DATE :"+BACKUPS.get("DATE").toString()+"\n");
    fileInfo.append("App version :"+BACKUPS.get("VERSION")+"\n");
    fileInfo.append("----RECORDS---------->\n");
    if(BACKUPS.get("ORDERS")!=null)
    {
    Properties os=(Properties)BACKUPS.get("ORDERS");
    reOrders.setEnabled(true);
    fileInfo.append("Order Records :"+os.size()+"\n");
    }
    if(BACKUPS.get("EVENTS")!=null)
    {
    Properties os=(Properties)BACKUPS.get("EVENTS");
    reEvents.setEnabled(true);
    fileInfo.append("Events Records :"+os.size()+"\n");
    }
    if(BACKUPS.get("MEALS")!=null)
    {
    Properties os=(Properties)BACKUPS.get("MEALS");
    reMeals.setEnabled(true);
    fileInfo.append("Meals Records :"+os.size()+"\n");
    }
    if(BACKUPS.get("RESERVATION")!=null)
    {
    Properties os=(Properties)BACKUPS.get("RESERVATION");
    reRes.setEnabled(true);
    fileInfo.append("Reservation Records :"+os.size()+"\n");
    }
    if(BACKUPS.get("STAFF")!=null)
    {
    Properties os=(Properties)BACKUPS.get("STAFF");
    reStaff.setEnabled(true);
    fileInfo.append("Staff Records :"+os.size()+"\n");
    }
    }
    private void pickFileanValidate()
    {
      String WHERE="pickFileanValidate():";
     JFileChooser choose=new JFileChooser();
     choose.setAcceptAllFileFilterUsed(false);
     choose.setFileSelectionMode(JFileChooser.FILES_ONLY);
     choose.addChoosableFileFilter(new FileNameExtensionFilter("Foody Backup Files","fbup"));
     switch(choose.showOpenDialog(this))
     {
      case JFileChooser.APPROVE_OPTION:
      File bFile=choose.getSelectedFile();
     {
         try
         {
          if(bFile.exists())
          {
              BACKUPS.clear();
              ObjectInputStream oio=new ObjectInputStream(new FileInputStream(bFile));
              BACKUPS=(Properties) oio.readObject();
              if(!BACKUPS.isEmpty()||BACKUPS!=null)
              {
              sourcePath.setText(bFile.getAbsolutePath());
              groomRestoreOptions();
              }
              else
              {
              fileInfo.setText("This backup file is corrupt");
              }
          }
         }
         catch (FileNotFoundException e) 
         {
          fileInfo.setText("An error occured while trying to retrieve the backup file\nPlease try again");
          HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
         }
         catch (IOException e) 
         {
            fileInfo.setText("An error occured while trying to retrieve the backup file\nPlease try again");
            HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
         }
         catch (ClassNotFoundException e) 
         {
           fileInfo.setText("An error occured while trying to retrieve the backup file\nPlease try again");
           HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
         }
     }
        
             break;
         case JFileChooser.CANCEL_OPTION:
             break;
     }    
    }
    public void initiateOperation()
    {
    JCheckBox[] cbs={reOrders,reEvents,reMeals,reRes,reStaff};
    for(JCheckBox c: cbs)
    {
      c.setSelected(false);
      c.setEnabled(false);
    }
    sourcePath.setText("");
    fileInfo.setText("");
    restore.setEnabled(false);
    create.setEnabled(false);
    this.setVisible(true);
    }
    private void backupOrders()
    {
    String WHERE="backupOrder():";
    String sql="SELECT * FROM orders WHERE hotel_id='"+MotherFrame.MY_ID+"'";
    ResultSet orders=MotherFrame.executeQuery(sql);
    if(orders!=null)
    {
    Properties p,records=new Properties();
    try
    {
    while(orders.next())
    {
    p=new Properties();
    p.put("order_id",orders.getInt("order_id"));
    p.put("list",orders.getString("list"));
    p.put("bill",orders.getFloat("bill"));
    p.put("duly_paid",orders.getString("duly_paid"));
    p.put("staff_id",orders.getString("staff_id"));
    p.put("date",orders.getDate("date"));
    records.put(orders.getInt("order_id"),p);
    }
    BACKUPS.put("ORDERS",records);
    }
    catch(Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    }
    private void backupEvents()
    {
    String sql="SELECT * FROM EVENTS WHERE hotel_id="+MotherFrame.MY_ID,WHERE="backupEvents():";
    ResultSet events=MotherFrame.executeQuery(sql);
    if(events!=null)
    {
    Properties p,records=new Properties();
    try
    {
    while(events.next())
    {
    p=new Properties();
    p.put("TITLE",events.getString("TITLE"));
    p.put("NOTE",events.getString("NOTE"));
    p.put("VENUE",events.getString("VENUE"));
    p.put("TIME",events.getDate("TIME"));
    records.put(events.getString("TITLE"),p);
    }
    BACKUPS.put("EVENTS",records);
    }
    catch(Exception e)
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    }
    private void backupStaff()
    {
    String sql="SELECT * FROM STAFF WHERE hotel_id="+MotherFrame.MY_ID+"",WHERE="backupStaff():";
    ResultSet recs=MotherFrame.executeQuery(sql);
    if(recs!=null)
    {
    Properties p,records=new Properties();
    try
    {
    while(recs.next())
    {
    p=new Properties();
    p.put("staff_id",recs.getString("staff_id"));
    p.put("name",recs.getString("name"));
    p.put("on_duty",recs.getString("on_duty"));
    p.put("age",recs.getString("age"));
    p.put("regno",recs.getString("regno"));
    p.put("id_no",recs.getString("id_no"));
    p.put("designation",recs.getString("designation"));
    p.put("rating",recs.getString("rating"));
    records.put(recs.getString("staff_id"),p);
    }
    BACKUPS.put("STAFF",records);
    }
    catch(Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    }
    private void backupReservations()
    {
    String sql="SELECT * FROM reservation WHERE hotel_id="+MotherFrame.MY_ID+"",WHERE="backupReservations():";
    ResultSet recs=MotherFrame.executeQuery(sql);
    if(recs!=null)
    {
    Properties p,records=new Properties();
    try
    {
    while(recs.next())
    {
    p=new Properties();
    p.put("recno",recs.getString("recno"));
    p.put("facility",recs.getString("facility"));
    p.put("fromtime",recs.getDate("from_time"));
    p.put("duration",recs.getInt("duration"));
    p.put("client_id",recs.getString("client_id"));
    p.put("mobile",recs.getString("mobile"));
    p.put("prepayment",recs.getFloat("prepayment"));
    p.put("cost",recs.getFloat("cost"));
    records.put(recs.getString("recno"),p);
    }
    BACKUPS.put("RESERVATION",records);
    }
    catch(Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    }
    private void backupMeals()
    {
    String sql="SELECT * FROM meals WHERE hotel_id="+MotherFrame.MY_ID+"",WHERE="backupMeals():";
    ResultSet recs=MotherFrame.executeQuery(sql);
    if(recs!=null)
    {
    Properties p,records=new Properties();
    try
    {
    while(recs.next())
    {
    p=new Properties();
    p.put("meal_id",recs.getString("meal_id"));
    p.put("meal_name",recs.getString("meal_name"));
    p.put("category",recs.getString("category"));
    p.put("unit",recs.getString("unit"));
    p.put("cost",recs.getFloat("cost"));
    p.put("available",recs.getString("available"));
    records.put(recs.getString("meal_id"),p);
    }
    BACKUPS.put("MEALS",records);
    }
    catch(Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    }
    private void createBackup(File f)
    {
        String WHERE="createFile():";
        File target=new File(f.getAbsolutePath()+".fbup");
        try
        {
          if(!target.exists())
          {
          target.createNewFile();
          }
          FileOutputStream toFile=new FileOutputStream(target);
          ObjectOutputStream oos=new ObjectOutputStream(toFile);
          //PrintStream writer=new PrintStream(target);
          BACKUPS.clear();
          if(forOrders.isSelected()){this.backupOrders();}
          if(forMeals.isSelected()){this.backupMeals();}
          if(forRes.isSelected()){this.backupReservations();}
          if(forStaff.isSelected()){this.backupStaff();}
          if(forEvents.isSelected()){this.backupEvents();}
          BACKUPS.put("DATE",new Date());
          BACKUPS.put("VERSION","1.0");
          oos.writeObject(BACKUPS);
          oos.flush();
          oos.close();
          this.setVisible(false);
          JOptionPane.showMessageDialog(this,"Backup Created at \n"+target.getAbsolutePath(),"Backup Successful",JOptionPane.INFORMATION_MESSAGE);
        }
        catch (IOException e) 
        {
         HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
        }
    }
    private void beginRestoration()
    {
     if(reOrders.isSelected()||reMeals.isSelected()||reStaff.isSelected()||reRes.isSelected()||reEvents.isSelected())
     {
     restoreBackupRecords();
     JOptionPane.showMessageDialog(this,"RestorationDone Please refresh the records",
             "OPERATION COMPLETE",JOptionPane.INFORMATION_MESSAGE);
     }
     else 
     {
     JOptionPane.showMessageDialog(this,"Please choose atleast one record to restore",
             "OPERATION NOT NECESSARY",JOptionPane.INFORMATION_MESSAGE);
     }
    }
    private void restoreBackupRecords()
    {
    if(reOrders.isSelected())
     {
     String createTable="CREATE TABLE IF NOT EXISTS ORDERS("
             + "order_id INT(10)  NOT NULL AUTO_INCREMENT,"
             + "hotel_id int(11) NOT NULL,"
             + "list varchar(100) NOT NULL ,"
             + "bill FLOAT NOT NULL,"
             + "duly_paid varchar(3) NOT NULL,"
             + "staff_id VARCHAR(30) NOT NULL,"
             + "date DATETIME DEFAULT 'CURRENT_TIMESTAMP',"
             + "PRIMARY KEY(order_id))";
     MotherFrame.executeUpdate(createTable);
     Properties ods=(Properties) BACKUPS.get("ORDERS");
     if(ods!=null)
     {
     restoreOrders(ods);
     }
     }
     if(reMeals.isSelected())
     {
     String createTable="CREATE TABLE IF NOT EXISTS meals("
             + "meal_id int(11) NOT NULL AUTO_INCREMENT,"
             + "meal_name varchar(30) NOT NULL,"
             + "hotel_id int(11) NOT NULL ,"
             + "category varchar(20) NOT NULL,"
             + "cost float NOT NULL DEFAULT 0,"
             + "available varchar(3) NOT NULL,"
             + "staff_id varchar(30) NOT NULL,"
             + "PRIMARY KEY(meal_id))";
     MotherFrame.executeUpdate(createTable);
     Properties ods=(Properties) BACKUPS.get("MEALS");
     if(ods!=null)
     {
     this.restoreStock(ods);
     }
     }
     if(reEvents.isSelected())
     {
     String createTable="CREATE TABLE IF NOT EXISTS EVENTS("
             + "REFNO INT(10) UNIQUE NOT NULL AUTO_INCREMENT,"
             + "TITLE VARCHAR(50) NULL,"
             + "TIME DATETIME NOT NULL,"
             + "VENUE varchar(5) NOT NULL,"
             +"NOTE VARCHAR(100) NOT NULL,"
             + "PRIMARY KEY(REFNO))";
     MotherFrame.executeUpdate(createTable);
     Properties ods=(Properties) BACKUPS.get("EVENTS");
     if(ods!=null)
     {
     this.restoreEvents(ods);
     }
     }
     if(reStaff.isSelected())
     {
     String createTable="CREATE TABLE IF NOT EXISTS staff("
             + "staff_id int(11)  NOT NULL UNIQUE,"
             + "staff_name varchar(30) NOT NULL ,"
             + "hotel_id int(11) NOT NULL,"
             + "on_duty varchar(3) NOT NULL,"
             + "age int(2) NOT NULL,"
             + "regno varchar(15) NOT NULL,"
             + "designation varchar(10) NOT NULL,"
             + "rating int(1),"
             + "PRIMARY KEY(staff_id))";
     MotherFrame.executeUpdate(createTable);
     Properties ods=(Properties) BACKUPS.get("STAFF");
     if(ods!=null)
     {
     this.restoreStaff(ods);
     }
     }
     if(reRes.isSelected())
     {
     String createTable="CREATE TABLE IF NOT EXISTS reservation("
             + "recno int(11)  NOT NULL AUTO_INCREMENT,"
             + "hotel_id int(11) NOT NULL,"
             + "client varchar(30) NOT NULL,"
             + "facility varchar(20) NOT NULL ,"
             + "from_time datetime DEFAULT 'CURRENT_TIMESTAMP',"
             + "duration bigint(20) NOT NULL,"
             + "client_id varchar(20) NOT NULL,"
             + "mobile varchar(20) NOT NULL,"
             + "prepayment float NOT NULL,"
             + "cost float NOT NULL,"
             + "PRIMARY KEY(recno))";
     MotherFrame.executeUpdate(createTable);
     Properties ods=(Properties) BACKUPS.get("RESERVATION");
     if(ods!=null)
     {
     this.restoreReservations(ods);
     }
     }
}
    private void restoreStaff(Properties staff)
    {
      Enumeration en=staff.keys();
      while(en.hasMoreElements())
      {
       Properties one=(Properties) staff.get(en.nextElement());
       String id=(String)one.get("staff_id"),name=(String)one.get("name"),
               onduty=(String)one.get("on_duty"),age=(String)one.get("age"),
               regno=(String)one.get("regno"),desig=(String)one.get("designation"),
               rating=(String) one.get("rating"),
               idno=""+one.get("id_no");
       String update="UPDATE STAFF SET name='"+name+"',regno='"+regno+"',age="+age+",designation='"+desig+"',"
               + "rating="+rating+",on_duty='"+onduty+"',id_no='"+idno+"',hotel_id="+MotherFrame.MY_ID+" WHERE staff_id="+id+"";
       String insert="INSERT INTO STAFF(staff_id,name,regno,age,id_no,designation,rating,on_duty,hotel_id) "
               + "VALUES("+id+",'"+name+"','"+regno+"',"+age+",'"+idno+"','"+desig+"',"+rating+",'"+onduty+"',"+MotherFrame.MY_ID+")";
       if(MotherFrame.executeUpdate(update)==0)
       {
       MotherFrame.executeUpdate(insert);
       }
      }
    }
    private void restoreReservations(Properties reservations)
    {
     Enumeration en=reservations.keys();
      while(en.hasMoreElements())
      {
       Properties one=(Properties) reservations.get(en.nextElement());
       String id=(String)one.get("recno"),
               client=(String)one.get("client"),
               facility=(String)one.get("facility"),
               fromtime=""+one.get("fromtime"),
               duration=""+one.get("duration"),
               mobile=(String)one.get("mobile"),
               prepayment=""+ one.get("prepayment"),
               cost=""+one.get("cost"),
               cid=""+one.get("client_id");
       String update="UPDATE RESERVATION SET recno='"+id+"',client='"+client+"',facility='"+facility+"',from_time='"+fromtime+"',"
               + "duration="+duration+",mobile='"+mobile+"',prepayment="+prepayment+",cost="+cost+",client_id='"+cid+"'"
               +"WHERE recno='"+id+"'";
       String insert="INSERT INTO RESERVATION(client,hotel_id,facility,client_id,from_time,duration,prepayment,cost,mobile) "
               + "VALUES('"+client+"',"+MotherFrame.MY_ID+",'"+facility+"','"+id+"','"+fromtime+"',"+duration+","+prepayment+","
               +cost+",'"+mobile+"')";
       if(MotherFrame.executeUpdate(update)==0)
        {
        MotherFrame.executeUpdate(insert);
        }
      }
    }
    private void restoreEvents(Properties events)
    {
     Enumeration en=events.keys();
      while(en.hasMoreElements())
      {
       Properties one=(Properties) events.get(en.nextElement());
       String title=(String)one.get("TITLE"),note=(String)one.get("NOTE"),venue=(String)one.get("VENUE"),
               time=""+one.get("TIME");
       String update="UPDATE EVENTS SET TITLE='"+title+"',NOTE='"+note+"',VENUE="+venue+",TIME='"+time+"' WHERE TITLE="+title
               +" AND TIME='"+time+"'";
       String insert="INSERT INTO EVENTS(TITLE,NOTE,TIME,VENUE) "
               + "VALUES('"+title+"','"+note+"',"+time+",'"+venue+"')";
       if(MotherFrame.executeUpdate(update)==0)
       {
       MotherFrame.executeUpdate(insert);
       }
      }
    }
    private void restoreStock(Properties stock)
    {
      Enumeration en=stock.keys();
      while(en.hasMoreElements())
      {
       Properties one=(Properties) stock.get(en.nextElement());
       String meal=(String)one.get("meal_name"),
               id=(String)one.get("meal_id"),
               category=(String)one.get("category"),
               unit=(String)one.get("unit"),
               cost=""+one.get("cost"),
               available=(String)one.get("available");
       String update="UPDATE meals SET meal_name='"+meal+"',category='"+category+"',unit='"+unit+"',cost="
               +cost+",available='"+available+"' WHERE meal_id='"+id+"'";
       String insert="INSERT INTO meals(meal_name,category,unit,cost,hotel_id) "
               + "VALUES('"+meal+"','"+category+"','"+unit+"',"+cost+","+MotherFrame.MY_ID+")";
       if(MotherFrame.executeUpdate(update)==0)
       {
       MotherFrame.executeUpdate(insert);
       }
      }
    }
    private void restoreOrders(Properties orders)
    {
      Enumeration en=orders.keys();
      while(en.hasMoreElements())
      {
       Properties one=(Properties) orders.get(en.nextElement());
       String id=""+one.get("order_id"),
               list=""+one.get("list"),
               bill=""+one.get("bill"),
               dulypaid=(String)one.get("duly_paid"),
               hotel=""+MotherFrame.MY_ID,
               waiter=(String)one.get("staff_id"),
               date=""+one.get("date");
       String update="UPDATE ORDERS SET list='"+list+"',bill="+bill+",duly_paid='"+dulypaid+"',"
               + "hotel_id='"+hotel+"',staff_id='"+waiter+"',date='"+date+"' WHERE order_id="+id;
       
       String insert="INSERT INTO ORDERS(list,bill,duly_paid,hotel_id,staff_id,date) "
               + "VALUES('"+list+"',"+bill+",'"+dulypaid+"',"+hotel+",'"+waiter+"','"+date+"')";
       if(MotherFrame.executeUpdate(update)==0)
       {
       MotherFrame.executeUpdate(insert);
       }
      }
    }

private class EventsHandler implements ActionListener,ItemListener{

        @Override
        public void actionPerformed(ActionEvent e) 
        {
        if(e.getSource() instanceof JButton)
        {
        buttonClicked((JButton) e.getSource());
        }
        }

        @Override
        public void itemStateChanged(ItemEvent e) 
        {
         if(e.getSource() instanceof JCheckBox)
         {
         checkBoxStateChanged((JCheckBox)e.getSource());
         }
        }

}
}