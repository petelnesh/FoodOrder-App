/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tabberView;

import com.sun.glass.events.KeyEvent;
import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

/**
 *
 * @author Eric
 */
public class ReservationMaker extends JDialog{
public final JPanel mother,clientForm,facilityForm,buttonsPanel;
public final JButton make,cancel,reset,update;
public final JComboBox facility;
public final JTextField client,id,mobile,prepay,duration,totalCost;
public final JSpinner hour,min;
private final Font forFields=new Font(Font.DIALOG_INPUT,Font.ITALIC,17);
private final EventsHandler eventsHandler;
private final JDatePanelImpl pk;
private final JDatePickerImpl fromTime;
public String primary;
private static final String MODULE="ReservationMaker:";
public ReservationMaker()
{
this.setModal(true);
this.setSize(450,400);
this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
this.setIconImage(MotherFrame.icon);
eventsHandler=new EventsHandler();
Container contentPane=this.getContentPane();
mother=new JPanel();
mother.setPreferredSize(new Dimension(400,330));
mother.setLayout(new BorderLayout());
clientForm=new JPanel();
clientForm.setLayout(new GridLayout(5,1));
facilityForm=new JPanel();
facilityForm.setLayout(new GridLayout(5,1));
buttonsPanel=new JPanel();
make=new JButton("Make ");
make.setMnemonic(KeyEvent.VK_M);
make.setPreferredSize(new Dimension(90,40));
make.addActionListener(eventsHandler);
update=new JButton("Update");
update.setMnemonic(KeyEvent.VK_U);
update.setPreferredSize(new Dimension(90,40));
update.addActionListener(eventsHandler);
cancel=new JButton("Cancel");
cancel.addActionListener(eventsHandler);
cancel.setPreferredSize(new Dimension(90,40));
cancel.setMnemonic(KeyEvent.VK_C);
reset=new JButton("Reset");
reset.setPreferredSize(new Dimension(90,40));
reset.addActionListener(eventsHandler);
reset.setMnemonic(KeyEvent.VK_R);
buttonsPanel.add(make);
buttonsPanel.add(reset);
buttonsPanel.add(cancel);
UtilDateModel um=new UtilDateModel();
um.setDate(2016,04,06);
Properties p=new Properties();
p.put("text.today","Today");
p.put("text.month","Month");
p.put("text.year","Year");
pk=new JDatePanelImpl(um,p);
fromTime=new JDatePickerImpl(pk,new DateLabelFormat());
fromTime.setPreferredSize(new Dimension(200,45));
fromTime.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLoweredBevelBorder(),"Select Date"));
fromTime.setFont(forFields);
hour=new JSpinner();
hour.setPreferredSize(new Dimension(100,50));
hour.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE),"Hour"));
hour.setModel(new SpinnerNumberModel(00,0,23,1));
min=new JSpinner();
min.setPreferredSize(new Dimension(100,50));
min.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE),"Minutes"));
min.setModel(new SpinnerNumberModel(0,0,59,1));
JPanel time=new JPanel();
time.setLayout(new GridLayout(1,2));
time.add(hour);
time.add(min);
facility=new JComboBox();
facility.setPreferredSize(new Dimension(200,30));
facility.addItemListener(eventsHandler);
client=new JTextField(15);
client.setName("Client Name");
client.setFont(forFields);
id=new JTextField(15);
id.setName("Client ID No.");
id.setFont(forFields);
mobile=new JTextField(15);
mobile.setFont(forFields);
mobile.setName("Mobile No.");
prepay=new JTextField(15);
prepay.setFont(forFields);
prepay.setName("Prepaid Amount");
duration=new JTextField(15);
duration.setFont(forFields);
duration.setName("Duration");
duration.setName("Duration (Hours)");
totalCost=new JTextField(15);
totalCost.setFont(forFields);
totalCost.setName("Cost Per/Time");
totalCost.setName("Total Cost");
totalCost.setEditable(false);
JTextField[] clnt={client,id,mobile,prepay};
for(JTextField tf:clnt)
{
JPanel jp=new JPanel();
tf.setPreferredSize(new Dimension(200,30));
jp.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLoweredBevelBorder(),tf.getName()));
jp.add(tf);        
clientForm.add(jp);
}
JTextField[] fcl={duration,totalCost};
JPanel forF=new JPanel(),
        forT=new JPanel();
forF.add(facility);
forF.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE),"Select Facility"));
forT.add(time);
facilityForm.add(forF);
facilityForm.add(fromTime);
facilityForm.add(forT);
for(JTextField tf:fcl)
{
JPanel jp=new JPanel();
tf.setPreferredSize(new Dimension(150,30));
jp.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE),tf.getName()));
jp.add(tf);
facilityForm.add(jp);
}
getFacilities();
JPanel split=new JPanel();
split.add(clientForm);
split.add(facilityForm);
split.setLayout(new GridLayout(1,2));
mother.add(split,BorderLayout.CENTER);
mother.add(buttonsPanel,BorderLayout.SOUTH);
contentPane.add(new JScrollPane(mother));
}
private void getCostPerUnit()
{
String sql="SELECT duration,totalcost FROM facilities WHERE REGNAME='"+facility.getSelectedItem()+"'";
ResultSet rs=MotherFrame.executeQuery(sql);
String WHERE="getCostPerUnit():";
try
{
if(rs!=null&&rs.first())
{
totalCost.setText(rs.getString("TOTALCOST"));
duration.setText(rs.getString("DURATION"));
}
}
catch(Exception e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
}
}
private void getFacilities()
{
    String sql="SELECT REGNAME FROM FACILITIES WHERE hotel_id="+MotherFrame.MY_ID,WHERE="getFacilities():";
    ResultSet rs=MotherFrame.executeQuery(sql);
    if(rs!=null)
    {
    try 
    {
        while(rs.next())
        {
          facility.addItem(rs.getString("REGNAME"));
        }
        rs.close();
    }
    catch (SQLException e) 
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
}
private void comboBoxSelected(int state,JComboBox src)
{
  switch(state)
  {
      case ItemEvent.SELECTED:
          if(src.equals(facility))
          {
          getCostPerUnit();
          }
          break;
      case ItemEvent.DESELECTED:
          
          break;
  }
}
private void addReservation()
{
String WHERE="addReservation():";
String date=fromTime.getModel().getYear()+"-"+fromTime.getModel().getMonth()+"-"+fromTime.getModel().getDay()+" ",
time=hour.getValue()+":"+min.getValue()+":00";
String cName=client.getText(),
        idno=id.getText(),
        fac=(String)facility.getSelectedItem(),
        timeStamp=date+time,
        tel=mobile.getText(),
        prep=prepay.getText(),
        period=duration.getText(),
        total=totalCost.getText();
fromTime.setTextEditable(true);
if(!date.equals("")&&!cName.equals("")&&!idno.equals("")&&!tel.equals("")&&!idno.equals("")&&!prep.equals(""))
{
String sql="INSERT INTO reservation(client,facility,from_time,duration,client_id,mobile,prepayment,cost,hotel_id)"
        + "VALUES('"+cName+"','"+fac+"','"+timeStamp+"',"+period+",'"+idno+"','"+tel+"',"+prep+","+total+","+MotherFrame.MY_ID+")";
try
{
int rw=MotherFrame.executeUpdate(sql);
JOptionPane.showMessageDialog(this,"RESERVATION MADE SUCCESSFULLY","DONE",JOptionPane.INFORMATION_MESSAGE);
this.setVisible(false);
}
catch(Exception e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
}
}
else
{
JOptionPane.showMessageDialog(this,"All details are needed.\nPlease Enter all the details before proceediing","Missing Information",JOptionPane.WARNING_MESSAGE);
}
}
private void doUpdate()
{
String WHERE="doUpdate():";
String date=fromTime.getModel().getYear()+"-"+fromTime.getModel().getMonth()+"-"+fromTime.getModel().getDay()+" ",
time=hour.getValue()+":"+min.getValue()+":00";
String cName=client.getText(),
        idno=id.getText(),
        fac=(String)facility.getSelectedItem(),
        timeStamp=date+time,
        tel=mobile.getText(),
        prep=prepay.getText(),
        period=duration.getText(),
        total=totalCost.getText();
if(date!=null&&!cName.equals("")&&!idno.equals("")&&!tel.equals("")&&!idno.equals("")&&!prep.equals(""))
{
String sql="UPDATE reservation SET client='"+cName+"',facility='"+fac+"',fromtime='"+timeStamp+"',"
        + " duration="+period+",client_id='"+idno+"',mobile='"+tel+"',prepayment="+prep+",cost="+total+" WHERE recno="+primary;
try
{
if(MotherFrame.executeUpdate(sql)>0)
{
this.setVisible(false);
JOptionPane.showMessageDialog(this,"RECORD HAS BEEN SUCCESSFULLY UPDATED","UPDATED",JOptionPane.INFORMATION_MESSAGE);
}
}
catch(Exception e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
}
}
else
{
JOptionPane.showMessageDialog(this,"All details are needed.\nPlease Enter all the details before proceediing","Missing Information",JOptionPane.WARNING_MESSAGE);
}
}
private void buttonClicked(JButton src)
{
if(src.equals(cancel))
{
this.setVisible(false);
}
else if(src.equals(reset))
{
JTextField[] fls={client,id,mobile,prepay,duration,totalCost};
for(JTextField fd: fls)
{
fd.setText("");
}
}
else if(src.equals(make))
{
addReservation();
}
else if(src.equals(update))
{
doUpdate();
}
}
private class EventsHandler implements ActionListener,KeyListener,ItemListener{

        @Override
        public void actionPerformed(ActionEvent e) 
        {
          if(e.getSource() instanceof JButton)
          {
          buttonClicked((JButton)e.getSource());
          }
        }
        @Override
        public void keyTyped(java.awt.event.KeyEvent e) 
        {
         
        }
        @Override
        public void keyPressed(java.awt.event.KeyEvent e) 
        {
         
        }
        @Override
        public void keyReleased(java.awt.event.KeyEvent e) 
        {
         
        }

        @Override
        public void itemStateChanged(ItemEvent e) 
        {
        if(e.getSource() instanceof JComboBox)
        {
        comboBoxSelected(e.getStateChange(),(JComboBox)e.getSource());
        }
        }

    }
private class DateLabelFormat extends AbstractFormatter{
private final SimpleDateFormat formatter=new SimpleDateFormat("dd/MM/yyyy");
        @Override
        public Object stringToValue(String text) throws ParseException
        {
        return formatter.parseObject(text);
        }
        @Override
        public String valueToString(Object value) throws ParseException 
        {
          if(value!=null)
          {
          Calendar cal=(Calendar) value;
          return formatter.format(cal.getTime());
          }
          return "";
        }
}
}