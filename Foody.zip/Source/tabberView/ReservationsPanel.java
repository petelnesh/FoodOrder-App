
package tabberView;

import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.print.PrinterException;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Eric Kamunge
 * @email kamungeeric@gmail.com
 */
public class ReservationsPanel extends JPanel{
private final JMenuItem refresh=new JMenuItem("Refresh"),
        add=new JMenuItem("Add New"),
        print=new JMenuItem("Print Orders"),
        edit=new JMenuItem("Edit Record"),
        delete=new JMenuItem("Delete"),
        view=new JMenuItem("View");
private final JDialog detailsView;
private final JButton dismiss=new JButton("Back"),
        printOrder=new JButton("Print"),
        refreshAll=new JButton("Refresh");
private final JTextArea orderDetails=new JTextArea();
private final JLabel orderLabel=new JLabel("Örder Details");
private final JTable reservations;
private final JPanel searchBar;
private final JTextField searchText=new JTextField(20);
private final JButton addNew=new JButton("Add New");
private final JScrollPane scroll;
public static final JComboBox searchCriteria=new JComboBox();
private final JPopupMenu popM;
private final EventsHandler eventsHandler=new EventsHandler();
private final Color THEMECOLOR=MotherFrame.THEMECOLOR;
private int selectedRow;
public static Point loc;
private static final String MODULE="ReservationsPanel:";
public final ReservationMaker rMaker;
public ReservationsPanel()
{
        this.popM = new JPopupMenu();
        this.searchBar = new JPanel();
        this.reservations = new JTable();
//JMenuItems
view.addActionListener(eventsHandler);
refresh.addActionListener(eventsHandler);
add.addActionListener(eventsHandler);
print.addActionListener(eventsHandler);
edit.addActionListener(eventsHandler);
delete.addActionListener(eventsHandler);
//Popupmenu
 popM.addSeparator();
 popM.setBorder(BorderFactory.createLineBorder(Color.blue,4,true));
 popM.add(view);
 popM.addSeparator();
 popM.add(add);
 popM.addSeparator();
 popM.add(refresh);
 popM.addSeparator();
 popM.add(print);
 popM.addSeparator();
 popM.setBackground(THEMECOLOR);
 if(MotherFrame.PRIVILEGE.equals("ADMIN"))
 {
 popM.add(edit);
 popM.addSeparator();
 popM.add(delete);
 popM.addSeparator();
 }
//
detailsView=new JDialog();
detailsView.setIconImage(MotherFrame.icon);
detailsView.setLayout(new BorderLayout());
detailsView.setSize(300,300);
detailsView.setResizable(true);
detailsView.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
//
rMaker=new ReservationMaker();
rMaker.setLocationRelativeTo(this);
//
reservations.setFont(MotherFrame.tableFont);
reservations.setGridColor(Color.blue);
reservations.setRowHeight(25);
reservations.setAutoCreateColumnsFromModel(true);
reservations.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION );
reservations.setUpdateSelectionOnSort(true);
reservations.setCellSelectionEnabled(true);
reservations.setRowSelectionAllowed(true);
reservations.setColumnSelectionAllowed(false);
reservations.setSelectionBackground(THEMECOLOR);
reservations.addKeyListener(eventsHandler);
reservations.setComponentPopupMenu(popM);
reservations.addMouseListener(eventsHandler);
searchText.addKeyListener(eventsHandler);
addNew.addActionListener(eventsHandler);
refreshAll.addActionListener(eventsHandler);
searchBar.add(searchText);
JLabel sby=new JLabel("Search by");
sby.setLabelFor(searchCriteria);
sby.setForeground(THEMECOLOR);
searchBar.add(sby);
searchBar.add(searchCriteria);
searchBar.add(addNew);
searchBar.add(refreshAll);
searchBar.setBackground(Color.darkGray);
this.setLayout(new BorderLayout());
this.setBackground(THEMECOLOR);
scroll=new JScrollPane(reservations);
this.add(scroll,BorderLayout.CENTER);
this.add(searchBar,BorderLayout.NORTH);
loc=reservations.getLocation();
refreshRes();
groomDetailsView();
}
private void groomDetailsView()
{
orderDetails.setEditable(false);
orderDetails.setWrapStyleWord(true);
orderDetails.setText("");
orderDetails.setLineWrap(true);
detailsView.add(orderLabel,BorderLayout.NORTH);
detailsView.add(new JScrollPane(orderDetails),BorderLayout.CENTER);
JPanel buttons=new JPanel();
dismiss.addActionListener(eventsHandler);
printOrder.addActionListener(eventsHandler);
buttons.add(printOrder);
buttons.add(dismiss);
detailsView.add(buttons,BorderLayout.SOUTH);
}
private void viewDetails()
{
orderDetails.setText("");
TableModel model=reservations.getModel();
for(int i=0;i<model.getColumnCount();i++)
{
orderDetails.append("\n  "+model.getColumnName(i)+": "+model.getValueAt(reservations.getSelectedRow(),i));
}
detailsView.setLocationRelativeTo(this);
detailsView.setVisible(true);
selectedRow=0;
}
public void refreshRes()
{
   selectedRow=0;
   ResultSet data1=null;
   String getBooks="SELECT recno,client,facility,from_time,duration,client_id,mobile,prepayment,cost FROM reservation WHERE hotel_id="+MotherFrame.MY_ID,WHERE="refreshRes():";
   try
   {
   data1=MotherFrame.executeQuery(getBooks);
   reservations.setModel(MotherFrame.getModel(data1));
   reservations.enableInputMethods(false);
   this.setCriteria();
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"An EXception Occured\n"+e.getMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }
   finally
   {
    try
    {
     data1.close();
     }
    catch (Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
  }
   }
private void setCriteria()
{
searchCriteria.removeAllItems();
int cols=reservations.getModel().getColumnCount();
for(int t=0;t<cols;t++)
{
searchCriteria.addItem(reservations.getModel().getColumnName(t).toUpperCase());
}
}
private void buttonClicked(JButton src)
{
    String WHERE="buttonClicked(JButton):";
   if(src.equals(addNew))
         {
         add.doClick();
         }
         else if(src.equals(dismiss))
         {
          detailsView.setVisible(false);
         }
         else if(src.equals(refreshAll))
         {
          this.refreshRes();
         }
         else if(src.equals(printOrder))
         {
       try
       {
        orderDetails.print();
       }
       catch (PrinterException e) 
       {
        HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
       }
         }
}
private void editEntry()
{
String  client=(String)reservations.getValueAt(reservations.getSelectedRow(),1),
        facility=(String)reservations.getValueAt(reservations.getSelectedRow(),2),
        duration=""+reservations.getValueAt(reservations.getSelectedRow(),4),
        id=""+reservations.getValueAt(reservations.getSelectedRow(),4),
        mobile=""+reservations.getValueAt(reservations.getSelectedRow(),5),
        pPay=""+reservations.getValueAt(reservations.getSelectedRow(),6),
        cost=""+reservations.getValueAt(reservations.getSelectedRow(),7);
        rMaker.primary=""+reservations.getValueAt(reservations.getSelectedRow(),0);
rMaker.client.setText(client);
rMaker.facility.setSelectedItem(facility);
rMaker.duration.setText(duration);
rMaker.id.setText(id);
rMaker.mobile.setText(mobile);
rMaker.prepay.setText(pPay);
rMaker.totalCost.setText(cost);
rMaker.buttonsPanel.removeAll();
rMaker.buttonsPanel.add(rMaker.update);
rMaker.buttonsPanel.add(rMaker.reset);
rMaker.buttonsPanel.add(rMaker.cancel);
rMaker.setVisible(true);
refreshRes();
}
private void deleteEntry()
{
String recno=(String)reservations.getValueAt(reservations.getSelectedRow(),0);
String sql="DELETE FROM reservation WHERE recno='"+recno+"'";
switch(JOptionPane.showConfirmDialog(this,"Delete Entry "+recno+"?", "SURE DELETE ENTRY",JOptionPane.YES_NO_OPTION))
{
    case JOptionPane.YES_OPTION:
        if(MotherFrame.executeUpdate(sql)>0)
        {
        refreshRes();
        //JOptionPane.showMessageDialog(this,"Deleted Successfully", "ENTRY DELETED ",JOptionPane.INFORMATION_MESSAGE);
        }
        break;
}
    
}
private void searchEntries()
{
   String text=searchText.getText(),field=(String)searchCriteria.getSelectedItem();
   ResultSet data1=null;
   String WHERE="searchEntries():";
   String getOrders="SELECT recno,client,facility,from_time,duration,client_id,mobile,prepayment,cost FROM reservation WHERE "+field+" LIKE '%"+text+"%' AND hotel_id="+MotherFrame.MY_ID;
   try
   {
   data1=MotherFrame.executeQuery(getOrders);
   reservations.setModel(MotherFrame.getModel(data1));
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"An EXception Occured\n"+e.getLocalizedMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }
   finally
   {
    try
    {
     data1.close();
     }
    catch (Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
  }
}
private void popupMenuItemSelected(JMenuItem source)
{
loc=reservations.getLocationOnScreen();
if(source.equals(refresh))
{
refreshRes();
}
else if(source.equals(add))
{
rMaker.buttonsPanel.removeAll();
rMaker.buttonsPanel.add(rMaker.make);
rMaker.buttonsPanel.add(rMaker.reset);
rMaker.buttonsPanel.add(rMaker.cancel);
rMaker.setVisible(true);
refreshRes();
}
else if(source.equals(view))
{
viewDetails();
}
else if(source.equals(edit))
{
  editEntry();
}
else if(source.equals(delete))
{
 deleteEntry();
}
else if(source.equals(print))
{
 reservations.print(reservations.getGraphics());
}
}
private class EventsHandler implements MouseListener,KeyListener,ActionListener
{
        @Override
        public void mouseClicked(MouseEvent e) 
        {
        int type=e.getID();
        switch(type)
        {
            case MouseEvent.MOUSE_CLICKED:
            switch(e.getButton())
            {
                case MouseEvent.BUTTON3:
                    popM.show(reservations,e.getX(),e.getY());
                    e.consume();
                    break;
                case MouseEvent.BUTTON1:
                    if(e.getClickCount()==2)
                    {
                    popupMenuItemSelected(view);
                    e.consume();
                    }
                    break;
            }
        }
        }

        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {}

        @Override
        public void mouseExited(MouseEvent e) {}
//The following are the keyListener overrides
        @Override
        public void keyTyped(KeyEvent e)
        {
        searchEntries();
        }
        @Override
        public void keyPressed(KeyEvent e)
        {
        if(e.getSource().equals(reservations)&&e.getKeyCode()==KeyEvent.VK_DELETE)
            {
            delete.doClick();
            }
        }

        @Override
        public void keyReleased(KeyEvent e)
        {
        searchEntries();
        }

        @Override
        public void actionPerformed(ActionEvent e) 
        {
         if(e.getSource() instanceof JButton)
         {
             buttonClicked((JButton) e.getSource());
         }
         else if(e.getSource() instanceof JMenuItem)
         {
         JMenuItem source=(JMenuItem) e.getSource();
         popupMenuItemSelected(source);
         }
        }

    }
}