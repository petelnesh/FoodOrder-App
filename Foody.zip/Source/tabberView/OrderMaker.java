package tabberView;

import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;

/**
 *
 * @author Eric Kamunge
 * @email kamungeeric@gmail.com
 */
public class OrderMaker extends JDialog{
private final Container contentPane =this.getContentPane();
private final JTextArea ordersList=new JTextArea();
private final JComboBox type=new JComboBox(),
        availableList=new JComboBox(),
        waiter=new JComboBox(),
        paid=new JComboBox(),
        table=new JComboBox();
private final String[] types=MotherFrame.MEALCATEGORIES;
private final JButton make=new JButton("Make"),
        cancel=new JButton("Cancel"),
        toList=new JButton("Add");
private final JPanel menu=new JPanel(),
        buttons=new JPanel();
private final JLabel subTotal=new JLabel();
private final JSpinner quantity=new JSpinner();
private final EventsHandler eventsHandler=new EventsHandler();
private final Properties priceList=new Properties();
private float bill=0f;
private String listString="";
private static final String MODULE="OrderMaker:";

public OrderMaker()
{
//This is constructor for making new order
this.setModal(true);
this.setTitle("Make New Order");
this.setSize(new Dimension(600,300));
this.setIconImage(MotherFrame.icon);
this.setLocation(OrdersPanel.loc);
this.setIconImage(MotherFrame.icon);
this.setLayout(new BorderLayout());
this.setLayout(new BorderLayout());
menu.setLayout(new GridLayout(1,5));
ordersList.setEditable(false);
type.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY),"CATEGORY"));
paid.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY),"PAID"));
waiter.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY),"WAITER"));
table.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY),"TABLE NUMBER"));
availableList.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.red),"AVAILABLE"));
quantity.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY),"QUANTITY"));
subTotal.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.blue),"BILL (KSH)"));
toList.addActionListener(eventsHandler);
for (String type1 : types){type.addItem(type1);}
type.setSelectedIndex(0);
type.addItemListener(eventsHandler);
quantity.setModel(new SpinnerNumberModel(1,1,20,1));
paid.addItem("No");
paid.addItem("Yes");
for(int i=1;i<=10;i++){table.addItem(""+i);}
menu.add(type);
menu.add(availableList);
menu.add(quantity);
menu.add(toList);
menu.add(cancel);
subTotal.setText(""+bill);
make.addActionListener(eventsHandler);
cancel.addActionListener(eventsHandler);
buttons.setLayout(new GridLayout(1,3));
buttons.add(waiter);
buttons.add(table);
buttons.add(paid);
buttons.add(subTotal);
buttons.add(make);
contentPane.add(menu,BorderLayout.NORTH);
contentPane.add(new JScrollPane(ordersList),BorderLayout.CENTER);
contentPane.add(buttons,BorderLayout.SOUTH);
fetchAvailable();
getWaiters();
this.setVisible(true);
}
private void getWaiters()
{
ResultSet names=null;
String WHERE="getWaiters():";
try
{
String query="SELECT name FROM staff WHERE DESIGNATION='waiter' AND on_duty='Yes' AND hotel_id="+MotherFrame.MY_ID;
names=MotherFrame.executeQuery(query);
if(names!=null&&!names.isClosed()&&names.first())
{
do
{
waiter.addItem(names.getString("name"));
}
while(names.next());
}
}
catch(Exception e)
{
 HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
}
finally
{
      try
      {
          names.close();
      } catch (Exception e)
      {
         HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
      }
}
}
private void fetchAvailable()
{
   ResultSet data1=null;
   String WHERE="fetchAvailable():";
   String getMeals="SELECT meal_name,cost FROM meals WHERE category ='"+type.getSelectedItem()+"' AND available='Yes' AND hotel_id="+MotherFrame.MY_ID;
   availableList.removeAllItems();
   try
   {
   data1=MotherFrame.executeQuery(getMeals);
   if(data1!=null&&data1.first())
   {
   do
   {
   String meal=data1.getString("meal_name");
   float cost=data1.getFloat("cost");
   availableList.addItem(meal);
   priceList.put(meal,cost);
   }
   while(data1.next());
   }
   }
    catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"Error Occured "+e.getLocalizedMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }
   finally
   {
    try
    {
     data1.close();
     }
    catch (Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
  } 
    }
private void ongezaKwaList()
{
String selected=(String)availableList.getSelectedItem();
float price=Float.parseFloat(""+priceList.get(selected));
int naba=Integer.parseInt(""+quantity.getValue());
float cost=price*naba;
bill+=cost;
ordersList.append("\n   "+selected+"....................(x"+naba+").");
listString+=selected+"(x"+naba+"),";
subTotal.setText(""+bill);
}
private void addOrder()
{
    String WHERE="addOrder():";
   String update="INSERT INTO ORDERS(list,bill,staff_id,duly_paid,hotel_id) VALUES('"+listString.toLowerCase()+"',"
           +bill+",'"+waiter.getSelectedItem()+"','"+paid.getSelectedItem()+"','"+MotherFrame.MY_ID+"')";
   if(listString.equals("")||bill<=0)
   {
   JOptionPane.showMessageDialog(this,"Order cannot have zero cost nor be empty.\nPlease Enter Details","ERROR",JOptionPane.WARNING_MESSAGE);
   }
   else 
   {
   try
   {
   int y=MotherFrame.executeUpdate(update);
   if(y==1)
   {
    JOptionPane.showMessageDialog(this,"Order Successfull","ORDER MADE",JOptionPane.INFORMATION_MESSAGE);
    quantity.setValue(1);
    availableList.setSelectedIndex(0);
    ordersList.setText("");
    paid.setSelectedItem("No");
   }
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"An EXception Occured\n"+e.getMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }
    }
    }
private void comboItemSelected(JComboBox src)
{
    if(src.equals(type))
    {
    fetchAvailable();
    }
}
private class EventsHandler implements ActionListener,ItemListener{

        @Override
        public void actionPerformed(ActionEvent e) 
        {
        if(e.getSource() instanceof JButton)
        {
        JButton src=(JButton) e.getSource();
        buttonClicked(src);
        }
        else if(e.getSource() instanceof JComboBox)
        {
        JComboBox src=(JComboBox) e.getSource();
        comboItemSelected(src);
        }
        }
           @Override
         public void itemStateChanged(ItemEvent e)
        {
            if(e.getSource() instanceof JComboBox&& e.getStateChange()==ItemEvent.SELECTED)
            {
            JComboBox source=(JComboBox) e.getSource();
            comboItemSelected(source);
            }
            
        }
        private void buttonClicked(JButton src) 
        {
            if(src.equals(make))
            {
            addOrder();
            }
            else if(src.equals(toList))
            {
             ongezaKwaList();
            }
            else if(src.equals(cancel))
            {
            OrderMaker.super.setVisible(false);
            }
        }
}
}
