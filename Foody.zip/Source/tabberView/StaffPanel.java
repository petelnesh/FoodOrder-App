
package tabberView;

import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.print.PrinterException;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

/**
 *
 * @author Eric Kamunge
 * @email kamungeeric@gmail.com
 */
public class StaffPanel extends JPanel{
private final JTable staff=new JTable();
private final JPanel searchBar=new JPanel();
private JPanel buttons;
private final JMenuItem refresh,delete,edit,add,print,view,dutyState;
private final JTextField searchText=new JTextField(20);
private final JButton addNew=new JButton("Add New"),
        refreshAll=new JButton("Refresh"),
        prnt,ok;
private JButton save,cancel,update,reset;
private JTextField staffName,staffId,staffReg;
private JSpinner staffAge;
private JComboBox staffDocket;
private final JScrollPane scroll;
private final JPopupMenu popM=new JPopupMenu();
private final EventsHandler eventsHandler=new EventsHandler();
private final JComboBox searchCriteria=new JComboBox();
private final JTextArea details;
private final JDialog detailsViewer;
private final StaffAdmission regForm;
private static final String MODULE="StaffPanel";
private final Color THEMECOLOR=MotherFrame.THEMECOLOR;
public StaffPanel()
{
//JMenuItem
refresh=new JMenuItem("Refresh");
add=new JMenuItem("Add New");
edit=new JMenuItem("Edit Details");
delete=new JMenuItem("Delete Record");
print=new JMenuItem("Print Orders");
view=new JMenuItem("View Details");
dutyState=new JMenuItem("");
popM.addPopupMenuListener(eventsHandler);
JMenuItem[] menus={view,add,edit,dutyState,refresh,delete,print};
for(JMenuItem mi: menus)
{
mi.addActionListener(eventsHandler);
popM.add(mi);
popM.addSeparator();
}
searchText.addKeyListener(eventsHandler);
searchBar.add(searchText);
JLabel sby=new JLabel("Search by");
sby.setLabelFor(searchCriteria);
sby.setForeground(THEMECOLOR);
addNew.addActionListener(eventsHandler);
refreshAll.addActionListener(eventsHandler);
searchBar.add(sby);
searchBar.add(searchCriteria);
searchBar.add(addNew);
searchBar.add(refreshAll);
scroll=new JScrollPane(staff);
searchBar.setBackground(Color.darkGray);
this.setLayout(new BorderLayout());
this.add(scroll,BorderLayout.CENTER);
this.add(searchBar,BorderLayout.NORTH);
this.setBackground(THEMECOLOR);
staff.setRowSelectionAllowed(true);
staff.setSelectionBackground(THEMECOLOR);
staff.setFont(MotherFrame.tableFont);
staff.setComponentPopupMenu(popM);
staff.setRowHeight(25);
staff.addKeyListener(eventsHandler);
staff.addMouseListener(eventsHandler);
this.refreshStaff();
this.setCriteria();
detailsViewer=new JDialog();
detailsViewer.setLayout(new BorderLayout());
detailsViewer.setSize(300,300);
detailsViewer.setIconImage(MotherFrame.icon);
detailsViewer.setBackground(THEMECOLOR);
detailsViewer.setLocationRelativeTo(this);
ok=new JButton("Back");
ok.addActionListener(eventsHandler);
prnt=new JButton("Print");
prnt.addActionListener(eventsHandler);
details=new JTextArea();
details.setEditable(false);
JPanel btns=new JPanel();
btns.add(ok);
btns.add(prnt);
detailsViewer.add(new JScrollPane(details),BorderLayout.CENTER);
detailsViewer.add(btns,BorderLayout.SOUTH);
regForm=new StaffAdmission();
regForm.setIconImage(MotherFrame.icon);
}
private void fetchDetails()
{
String id=(String) staff.getValueAt(staff.getSelectedRow(),0),WHERE="fetchDeatails():";
String sql="SELECT * FROM STAFF WHERE staff_id='"+id+"'";
ResultSet info = MotherFrame.executeQuery(sql);
if(info!=null)
{
    try
    {
     if(info.first())
     {
     details.setText("\tSTAFF ID: "+info.getString("staff_id")+"\n");
     details.setText("\tNAME: "+info.getString("name")+"\n");
     details.append("\tDESIGNATION: "+info.getString("designation")+"\n");
     details.append("\tREG NO: "+info.getString("regno")+"\n");
     details.append("\tAGE: "+info.getString("age")+"\n");
     details.append("\tRATED AS :"+info.getString("rating")+" Stars\n");
     details.append("\tONDUTY: "+info.getString("on_duty")+"\n");
     details.append("\tNATIONAL ID/PASSPORT: "+info.getString("id_no")+"\n");
     detailsViewer.setVisible(true);
     }
     info.close();
    } 
    catch (SQLException e)
    {
      HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    catch (Exception e)
    {
      HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
}
}
private void popupMenuClicked(JMenuItem source)
{
String WHERE="popupMenuSelected(JMenuItem):";
if(source.equals(view)&&staff.getSelectedRow()!=-1)
{
fetchDetails();
}
else if(source.equals(add))
{
newRecord();
}
else if(source.equals(edit)&&staff.getSelectedRow()!=-1)
{
 editRecord();
}
else if(source.equals(refresh))
{
refreshStaff();
}
else if(source.equals(delete)&&staff.getSelectedRow()!=-1)
{
    deleteRecord();
}
else if(source.equals(dutyState)&&staff.getSelectedRow()!=-1)
{
    int selected=staff.getSelectedRow();
    String id=(String)staff.getValueAt(selected,0);
    String st=(String)staff.getValueAt(selected,2);
    if(st.equals("Yes"))
    {
    MotherFrame.executeUpdate("UPDATE STAFF SET on_duty='No' WHERE staff_id='"+id+"'");
    }
    else if(st.equals("No"))
    {
    MotherFrame.executeUpdate("UPDATE STAFF SET on_duty='Yes' WHERE staff_id='"+id+"'");
    }
    refreshStaff();
}
else if(source.equals(print))
{
    try 
    {
        staff.print();
    } catch (PrinterException e) {
        HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
}
}
/**
 * Handles all the button clicks as passed by the ActionListener
*/
private void buttonClicked(JButton src)
{
 String WHERE="buttonCliked(JButton):";
if(src.equals(ok))
{
detailsViewer.setVisible(false);
}
if(src.equals(refreshAll))
{
this.refreshStaff();
}
else if(src.equals(save))
{
this.insertRecord();
}
else if(src.equals(reset))
{
this.clearRegForm();
}
else if(src.equals(update))
{
this.updateRecord();
}
else if(src.equals(addNew))
{
add.doClick();
}
else if(src.equals(cancel))
{
regForm.setVisible(false);
this.clearRegForm();
}
else if(src.equals(prnt))
{
    try 
    {
        details.print();
    } catch (PrinterException e) {
        HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
}
}
private void clearRegForm()
{
staffName.setText("");
staffId.setText("");
staffDocket.setSelectedIndex(0);
}
private void setCriteria()
{
int cols=staff.getModel().getColumnCount();
for(int t=0;t<cols;t++)
{
searchCriteria.addItem(staff.getModel().getColumnName(t));
}
}
/**
 * commits the changes made to the currently being edited record
*/
public void updateRecord()
{
String id=staffId.getText(),
        sName=staffName.getText(),
        reg=staffReg.getText(),
        age=""+staffAge.getValue(),
        desg=(String)staffDocket.getSelectedItem();
if(!id.equals("")&&!sName.equals("")&&!reg.equals("")&&!age.equals("")&&!desg.equals(""))
{
String sql="UPDATE staff SET name='"+sName+"',age="+age+",designation='"+desg+"' WHERE staff_id='"+id+"'";
if(MotherFrame.executeUpdate(sql)==1)
{
JOptionPane.showMessageDialog(this,sName+"\n Record Successifully Updated","RECORD UPDATED",JOptionPane.INFORMATION_MESSAGE);
}
else
{
JOptionPane.showMessageDialog(this,"ERROR OCCURED","Error occured while adding record",JOptionPane.ERROR_MESSAGE);
}
}
else
{
JOptionPane.showMessageDialog(this,"Please enter all the Details before saving","MISSING DETAILS",JOptionPane.ERROR_MESSAGE);
}
refreshStaff();
regForm.setVisible(false);
}
/**
Inserts the new staff record details into the database
*/
public void insertRecord()
{
String id=staffId.getText(),
        sName=staffName.getText(),
        reg=staffReg.getText(),
        age=""+staffAge.getValue(),
        desg=(String)staffDocket.getSelectedItem();
if(!id.equals("")&&!sName.equals("")&&!reg.equals("")&&!age.equals("")&&!desg.equals(""))
{
String sql="INSERT INTO staff(id_no,name,regno,age,designation,hotel_id) VALUES('"+id+"','"+sName+"','"+reg+"',"+age+",'"+desg+"',"+MotherFrame.MY_ID+")";
if(MotherFrame.executeUpdate(sql)==1)
{
JOptionPane.showMessageDialog(this,sName+"\n Record added","RECORD ADDED",JOptionPane.INFORMATION_MESSAGE);
}
else
{
JOptionPane.showMessageDialog(this,"ERROR OCCURED","Error occured while adding record",JOptionPane.ERROR_MESSAGE);
}
}
else
{
JOptionPane.showMessageDialog(this,"Please enter all the Details before saving","MISSING DETAILS",JOptionPane.ERROR_MESSAGE);
}
refreshStaff();
regForm.setVisible(false);
}
/**
* Displays the details form with existing staff record details for editing.
* The Regno field cannot be edited.
*/
public void editRecord()
{
String WHERE="editRecord():";
try
{
regForm.setTitle("Editing Staff Record");
String id=(String)staff.getValueAt(staff.getSelectedRow(),0);
String sql="SELECT * FROM STAFF WHERE staff_id='"+id+"'";
ResultSet info=MotherFrame.executeQuery(sql);
if(info!=null&&info.first())
{
staffName.setText(info.getString("name"));
staffReg.setText(info.getString("regno"));
staffDocket.setSelectedItem(info.getString("designation")); 
staffAge.setValue(info.getInt("age"));
staffId.setText(info.getString("id_no"));
staffId.setEditable(false);
staffReg.setEditable(false);
}
buttons.removeAll();
buttons.add(cancel);
buttons.add(update);
regForm.setLocationRelativeTo(this);
regForm.setVisible(true);
 }
 catch(Exception e)
 {
 HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
 }
}
/**
 * Displays a blank form to enter the new staff record details
*/
public void newRecord()
{
regForm.setTitle("Enter Staff Details");
buttons.removeAll();
buttons.add(cancel);
buttons.add(save);
regForm.setLocationRelativeTo(this);
regForm.setVisible(true);
}
/**
 Refreshes the staff records in the table from the database
 */
public final void refreshStaff()
{
   ResultSet data1=null;
   String getStaff="SELECT staff_id,name,on_duty,designation,rating FROM STAFF WHERE hotel_id="+MotherFrame.MY_ID,WHERE="refershStaff():";
   try
   {
   data1=MotherFrame.executeQuery(getStaff);
   staff.setModel(MotherFrame.getModel(data1));
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"An Exception Occured\n"+e.getLocalizedMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }
   finally
   {
    try
    {
     data1.close();
    }
    catch (Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
  }
   }
public void searchEntries()
{
   ResultSet data1=null;
   String text=searchText.getText(),field=(String)searchCriteria.getSelectedItem();
   String getStaff="SELECT staff_id,name,on_duty,designation,rating "
           + "FROM STAFF WHERE "+field+" LIKE '%"+text+"%' AND hotel_id="+MotherFrame.MY_ID,
           WHERE="searchEntries():";
   try
   {
   data1=MotherFrame.executeQuery(getStaff);
   staff.setModel(MotherFrame.getModel(data1));
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"An Exception Occured\n"+e.getLocalizedMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }
   finally
   {
    try
    {
     data1.close();
    }
    catch (Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
  }
}
private void chooseCommands()
{
int selected=staff.getSelectedRow();
    if(selected!=-1)
    {
    String st=(String)staff.getValueAt(selected,2);
    if(st.equals("Yes")){dutyState.setText("Relief Duty");}
    else if(st.equals("No")){dutyState.setText("Assign Duty");}
    }
}
private void deleteRecord()
{
      String id=(String)staff.getValueAt(staff.getSelectedRow(),0);
      switch(JOptionPane.showConfirmDialog(this,"Delete "+staff.getValueAt(staff.getSelectedRow(),1)+"'s Record?",
        "Delete Record?", JOptionPane.YES_NO_OPTION))
        {
            case JOptionPane.YES_OPTION:
                String sql="DELETE FROM STAFF WHERE staff_id='"+id+"'";
                int y=MotherFrame.executeUpdate(sql);
                this.refreshStaff();
                break;
        }
}
/**
 * This class represents the dialog for adding and update staff records details
 */

private class StaffAdmission extends JDialog{
public StaffAdmission()
{
this.setModal(true);
this.setMinimumSize(new Dimension(300,400));
this.setBackground(Color.BLUE);
update=new JButton("Save");
update.addActionListener(eventsHandler);
save=new JButton("Save");
save.addActionListener(eventsHandler);
cancel=new JButton("Cancel");
cancel.addActionListener(eventsHandler);
staffName=new JTextField(20);
staffName.setBorder(BorderFactory.createTitledBorder("Full Name"));
staffId=new JTextField(12);
staffId.setBorder(BorderFactory.createTitledBorder("Id/Passport Number"));
staffAge=new JSpinner();
//staffAge.setModel(new SpinnerNumberModel(1,18,100,1));
staffAge.setBorder(BorderFactory.createTitledBorder("Age"));
staffReg=new JTextField(20);
staffReg.setBorder(BorderFactory.createTitledBorder("Staff Number"));
staffDocket=new JComboBox();
staffDocket.setBorder(BorderFactory.createTitledBorder("Designation"));
staffDocket.addItem("Waiter");
staffDocket.addItem("Chef");
staffDocket.addItem("Overseer");
staffDocket.addItem("Unit Manager");
JPanel holderPane=new JPanel(),
        centerPane=new JPanel(),
        n=new JPanel(),
        ig=new JPanel(),
        d=new JPanel(),
        r=new JPanel(),
        idAge=new JPanel();
        buttons=new JPanel();
        n.add(staffName);
        ig.add(idAge);
        d.add(staffDocket);
        r.add(staffReg);
buttons.add(cancel);
idAge.setLayout(new BorderLayout());
idAge.add(staffId,BorderLayout.CENTER);
idAge.add(staffAge,BorderLayout.EAST);
centerPane.setLayout(new GridLayout(4,1));
centerPane.add(n);
centerPane.add(ig);
centerPane.add(r);
centerPane.add(d);
holderPane.setLayout(new BorderLayout());
holderPane.add(buttons,BorderLayout.SOUTH);
holderPane.add(centerPane,BorderLayout.CENTER);
this.add(holderPane);
}
}

private class EventsHandler implements ActionListener,PopupMenuListener,MouseListener,KeyListener{
        public EventsHandler() {}

        @Override
        public void actionPerformed(ActionEvent e) 
        {
         if(e.getSource() instanceof JMenuItem)
         {
         popupMenuClicked((JMenuItem) e.getSource());
         }
         if(e.getSource() instanceof JButton)
         {
         buttonClicked((JButton) e.getSource());
         }
        }
        @Override
        public void keyTyped(KeyEvent e)
        {
        searchEntries();
        }
        @Override
        public void keyPressed(KeyEvent e)
        {
        if(e.getSource().equals(staff)&&e.getKeyCode()==KeyEvent.VK_DELETE)
            {
            delete.doClick();
            }
        }

        @Override
        public void keyReleased(KeyEvent e)
        {
        searchEntries();
        }
        @Override
        public void popupMenuWillBecomeVisible(PopupMenuEvent e) 
        {
           chooseCommands();
        }

        @Override
        public void popupMenuWillBecomeInvisible(PopupMenuEvent e){}

        @Override
        public void popupMenuCanceled(PopupMenuEvent e){}

        @Override
        public void mouseClicked(MouseEvent e) 
        {
        if(e.getSource().equals(staff))
        {
         int type=e.getID();
        switch(type)
        {
            case MouseEvent.MOUSE_CLICKED:
            switch(e.getButton())
            {
                case MouseEvent.BUTTON3:
                    chooseCommands();
                    popM.show(staff,e.getX(),e.getY());
                    e.consume();
                    break;
                case MouseEvent.BUTTON1:
                    if(e.getClickCount()==2)
                    {
                    popupMenuClicked(view);
                    e.consume();
                    }
                    break;
            }
          }
        }
        }

        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e){}

        @Override
        public void mouseEntered(MouseEvent e){}

        @Override
        public void mouseExited(MouseEvent e) {}
    }
}