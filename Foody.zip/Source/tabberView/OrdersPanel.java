
package tabberView;

import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.print.PrinterException;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.table.TableModel;

/**
 *
 * @author Eric Kamunge
 * @email kamungeeric@gmail.com
 */
public class OrdersPanel extends JPanel{
private final JMenuItem refresh=new JMenuItem("Refresh"),
        add=new JMenuItem("Add New"),
        print=new JMenuItem("Print Orders"),
        delete=new JMenuItem("Delete"),
        setPaid=new JMenuItem("Set as Duly Paid"),
        view=new JMenuItem("View");
private final JDialog detailsView;
private final JButton dismiss=new JButton("Back"),
        printOrder=new JButton("Print"),
        refreshAll=new JButton("Refresh");
private final JTextArea orderDetails=new JTextArea();
private final JLabel orderLabel=new JLabel("Order Details");
private final JTable orders=new JTable();
private final JPanel searchBar=new JPanel();
private final JTextField searchText=new JTextField(20);
private final JButton addNew=new JButton("Add New");
private final JScrollPane scroll;
public static final JComboBox searchCriteria=new JComboBox();
private final JPopupMenu popM=new JPopupMenu();
private final OrdersListener eventsHandler=new OrdersListener();
private final Color THEMECOLOR=MotherFrame.THEMECOLOR;
private int selectedRow;
private static final String MODULE="OrdersPanel:";
public static Point loc;
public OrdersPanel()
{
//JMenuItems
view.addActionListener(eventsHandler);
refresh.addActionListener(eventsHandler);
add.addActionListener(eventsHandler);
print.addActionListener(eventsHandler);
setPaid.addActionListener(eventsHandler);
delete.addActionListener(eventsHandler);
//Popupmenu
 popM.addSeparator();
 popM.setUI(new com.sun.java.swing.plaf.windows.WindowsPopupMenuUI());
 popM.setBorder(BorderFactory.createLineBorder(Color.blue,4,true));
 popM.add(view);
 popM.addSeparator();
 popM.add(setPaid); popM.addSeparator();
 popM.add(add);
 if(MotherFrame.PRIVILEGE.equals("ADMIN"))
 {
 popM.addSeparator();
 popM.add(delete);
 }
 popM.addSeparator();
 popM.add(refresh);
 popM.addSeparator();
 popM.add(print);
 popM.addSeparator();
 popM.addPopupMenuListener(eventsHandler);
//
detailsView=new JDialog();
 //
orders.setFont(MotherFrame.tableFont);
orders.setGridColor(Color.blue);
orders.setRowHeight(25);
orders.setAutoCreateColumnsFromModel(true);
orders.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION );
orders.setUpdateSelectionOnSort(true);
orders.setCellSelectionEnabled(true);
orders.setRowSelectionAllowed(true);
orders.setColumnSelectionAllowed(false);
orders.setComponentPopupMenu(popM);
orders.setSelectionBackground(THEMECOLOR);
orders.addKeyListener(eventsHandler);
orders.addMouseListener(eventsHandler);
searchText.addKeyListener(eventsHandler);
searchBar.add(searchText);
JLabel sby=new JLabel("Search by");
sby.setLabelFor(searchCriteria);
sby.setForeground(THEMECOLOR);
addNew.addActionListener(eventsHandler);
refreshAll.addActionListener(eventsHandler);
searchBar.add(sby);
searchBar.add(searchCriteria);
searchBar.add(addNew);
searchBar.add(refreshAll);
searchBar.setBackground(Color.darkGray);
this.setLayout(new BorderLayout());
scroll=new JScrollPane(orders);
this.setBackground(THEMECOLOR);
this.add(scroll,BorderLayout.CENTER);
this.add(searchBar,BorderLayout.NORTH);
loc=orders.getLocation();
refreshOrders();
groomDetailsView();
}
private void groomDetailsView()
{
detailsView.setIconImage(MotherFrame.icon);
detailsView.setLayout(new BorderLayout());
detailsView.setSize(300,400);
detailsView.setResizable(true);
detailsView.setLocationRelativeTo(this);
detailsView.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
orderDetails.setEditable(false);
orderDetails.setWrapStyleWord(true);
orderDetails.setText("");
orderDetails.setLineWrap(true);
detailsView.add(orderLabel,BorderLayout.NORTH);
detailsView.add(new JScrollPane(orderDetails),BorderLayout.CENTER);
JPanel buttons=new JPanel();
dismiss.addActionListener(eventsHandler);
printOrder.addActionListener(eventsHandler);
buttons.add(printOrder);
buttons.add(dismiss);
detailsView.add(buttons,BorderLayout.SOUTH);
}
private void viewDetails()
{
TableModel model=orders.getModel();
orderDetails.setText("");
for(int i=0;i<model.getColumnCount();i++)
{
orderDetails.append("\n  "+model.getColumnName(i)+": "+model.getValueAt(orders.getSelectedRow(),i));
}
orderDetails.revalidate();
orderDetails.repaint();
detailsView.setVisible(true);
selectedRow=0;
}
public final void refreshOrders()
{
   selectedRow=0;
   ResultSet data1=null;
   String getBooks="SELECT order_id,list,bill,duly_paid,staff_id FROM ORDERS WHERE hotel_id="+MotherFrame.MY_ID,WHERE="refeshOrders():";
   try
   {
   data1=MotherFrame.executeQuery(getBooks);
   orders.setModel(MotherFrame.getModel(data1));
   orders.enableInputMethods(false);
   this.setCriteria();
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"An EXception Occured\n"+e.getMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }
   finally
   {
    try
    {
     data1.close();
     }
    catch (Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
  }
   }
private void setCriteria()
{
searchCriteria.removeAllItems();
int cols=orders.getModel().getColumnCount();
for(int t=0;t<cols;t++)
{
searchCriteria.addItem(orders.getModel().getColumnName(t).toUpperCase());
}
}
private void searchEntries()
{
   String text=searchText.getText(),field=(String)searchCriteria.getSelectedItem(),WHERE="searchEntries():";
   ResultSet data1=null;
   String getOrders="SELECT order_id,list,bill,duly_paid,staff_id FROM ORDERS WHERE hotel_id="+MotherFrame.MY_ID+" AND "+field.toLowerCase()+" LIKE '%"+text+"%'";
   try
   {
   data1=MotherFrame.executeQuery(getOrders);
   orders.setModel(MotherFrame.getModel(data1));
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"An EXception Occured\n"+e.getLocalizedMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }
   finally
   {
    try
    {
     data1.close();
     }
    catch (Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
  }
}
private void buttonClicked(JButton src)
{
String WHERE="buttonClicked(JButton):";
    
if(src.equals(addNew))
{
    add.doClick();
}
if(src.equals(refreshAll))
{
    refreshOrders();
}
else if(src.equals(dismiss))
{
    detailsView.setVisible(false);
}
else if(src.equals(printOrder))
{
try 
{
    orderDetails.print();
} 
catch (PrinterException ex) 
{
    HotelBiller.queueError(MODULE+WHERE+ex.toString()+":"+ex.getMessage());
}
}
}
private void deleteEntry()
{
String id=""+orders.getValueAt(orders.getSelectedRow(),0);
String sql="DELETE FROM orders WHERE order_id="+id;
switch(JOptionPane.showConfirmDialog(this,"Delete order no "+id+" ?", "SURE DELETE ENTRY?",JOptionPane.YES_NO_OPTION))
{
    case JOptionPane.YES_OPTION:
        if(MotherFrame.executeUpdate(sql)>0)
        {
        this.refreshOrders();
        //JOptionPane.showMessageDialog(this,"Deleted Successfully", "ENTRY DELETED ",JOptionPane.INFORMATION_MESSAGE);
        }
        break;
}
    
}
private void popupMenuItemSelected(JMenuItem source)
{
String WHERE="popupMenuSelected(JMenuItem):";
loc=orders.getLocationOnScreen();
if(source.equals(refresh))
{
this.refreshOrders();
}
else if(source.equals(add))
{
OrderMaker maker=new OrderMaker();
refreshOrders();
}
else if(source.equals(view))
{
viewDetails();
}
else if(source.equals(setPaid))
{
payOrder();
}
else if(source.equals(delete))
{
deleteEntry();
}
else if(source.equals(print))
{
    try 
    {
    orders.print();
    }
    catch (PrinterException e)
    {
      HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
}
}
private void chooseCommands()
{
String st=""+(String)orders.getValueAt(orders.getSelectedRow(),3);
if(st.equalsIgnoreCase("No"))
{
setPaid.setEnabled(true);
}
else
{
setPaid.setEnabled(false);
}
}
private void payOrder()
{
   int id=Integer.parseInt(""+orders.getValueAt(orders.getSelectedRow(),0));
   String addMenu="UPDATE orders SET duly_paid='Yes' WHERE order_id="+id+"";
   int rs=MotherFrame.executeUpdate(addMenu);
   refreshOrders();
   //JOptionPane.showMessageDialog(this,id+" Updated Successfully","ORDER UPDATED",JOptionPane.INFORMATION_MESSAGE);             
}
private class OrdersListener implements MouseListener,KeyListener,ActionListener,PopupMenuListener
{
        @Override
        public void mouseClicked(MouseEvent e) 
        {
        if(e.getSource().equals(orders))
        {
         int type=e.getID();
        switch(type)
        {
            case MouseEvent.MOUSE_CLICKED:
            switch(e.getButton())
            {
                case MouseEvent.BUTTON3:
                    popM.show(orders,e.getX(),e.getY());
                    e.consume();
                    break;
                case MouseEvent.BUTTON1:
                    if(e.getClickCount()==2)
                    {
                    popupMenuItemSelected(view);
                    e.consume();
                    }
                    break;
            }
          }
        }
        }

        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {}

        @Override
        public void mouseExited(MouseEvent e) {}
        //The following are the keyListener overrides
        @Override
        public void keyTyped(KeyEvent e)
        {
        searchEntries();
        }
        @Override
        public void keyPressed(KeyEvent e)
        {
        if(e.getSource().equals(orders)&&e.getKeyCode()==KeyEvent.VK_DELETE)
            {
            delete.doClick();
            }
        }

        @Override
        public void keyReleased(KeyEvent e)
        {
        searchEntries();
        }

        @Override
        public void actionPerformed(ActionEvent e) 
        {
          String WHERE="actionPerfomed(ActionEvent):";
         if(e.getSource() instanceof JButton)
         {
         buttonClicked((JButton)e.getSource());
         }
         else if(e.getSource() instanceof JMenuItem)
         {
         JMenuItem source=(JMenuItem) e.getSource();
         popupMenuItemSelected(source);
         }
        }

        @Override
        public void popupMenuWillBecomeVisible(PopupMenuEvent e) 
        {
        chooseCommands();
        }

        @Override
        public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {}

        @Override
        public void popupMenuCanceled(PopupMenuEvent e) {}

    }
}