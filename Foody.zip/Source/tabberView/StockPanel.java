
package tabberView;

import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.print.PrinterException;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.table.TableModel;

/**
 * @author Eric Kamunge
 * @email kamungeeric@gmail.com
 */
public class StockPanel extends JPanel{
private final JTable stock;
private JTextField mealName,mealUnit;
private JSpinner mealCost;
private JComboBox iko,category;
private final JPanel searchBar;
private final JTextField searchText;
private final JScrollPane scroll;
private final JPopupMenu popM=new JPopupMenu();
private final JButton addNew=new JButton("Add New"),
        addMeal=new JButton("Add"),
        refreshAll=new JButton("Refresh"),
        cancelAdd=new JButton("Cancel"),
        saveChange=new JButton("Update"),
        printMeal=new JButton("Print"),
        dismiss=new JButton("Cancel");
private final JComboBox searchCriteria=new JComboBox();
private final JMenuItem setAvailable=new JMenuItem("Make Available"),
        refresh=new JMenuItem("Refresh"),
        edit=new JMenuItem("Edit"),
        delete=new JMenuItem("Delete"),
        add=new JMenuItem("Add New"),
        print=new JMenuItem("Print Menu"),
        view=new JMenuItem("View Details"),
        setUnavailable=new JMenuItem("Make Unavailable");
private final JDialog menuAdder=new JDialog();
private final JDialog detailsView;
private final JTextArea mealDetails=new JTextArea();
private int selectedRow;
private static final String MODULE="StockPanel";
private final Color THEMECOLOR=MotherFrame.THEMECOLOR;
private final StockListener eventsHandler=new StockListener();
private final int EDIT=0,ADD=1;
public StockPanel()
{
        this.stock = new JTable();
        this.searchText = new JTextField(20);
        this.searchBar = new JPanel();
        this.setBackground(THEMECOLOR);
//JMennItems
add.addActionListener(eventsHandler);
refresh.addActionListener(eventsHandler);
edit.addActionListener(eventsHandler);
print.addActionListener(eventsHandler);
delete.addActionListener(eventsHandler);
setAvailable.addActionListener(eventsHandler);
setUnavailable.addActionListener(eventsHandler);
view.addActionListener(eventsHandler);
//
detailsView=new JDialog();
detailsView.setLayout(new BorderLayout());
detailsView.setSize(300,300);
detailsView.setIconImage(MotherFrame.icon);
detailsView.setBackground(THEMECOLOR);
detailsView.setLocationRelativeTo(this);
//Popupmenu
 popM.addSeparator();
 popM.add(view);
 popM.addSeparator();
 popM.setBorder(BorderFactory.createLineBorder(Color.blue,4,true));
 popM.add(add);
 popM.setUI(new com.sun.java.swing.plaf.windows.WindowsPopupMenuUI());
 popM.addSeparator();
 popM.add(print);
 popM.addSeparator();
 if(MotherFrame.PRIVILEGE.contains("ADMIN"))
 {
 popM.add(delete);
 popM.addSeparator();
 popM.add(edit);
 popM.addSeparator();
 popM.setBackground(THEMECOLOR);
 }
 popM.add(refresh);
 popM.addSeparator();
 popM.addPopupMenuListener(eventsHandler);
menuAdder.setModal(true);
menuAdder.setSize(new Dimension(400,400));
menuAdder.setLocationRelativeTo(this);
menuAdder.setIconImage(MotherFrame.icon);
searchText.addKeyListener(eventsHandler);
searchBar.add(searchText);
JLabel sby=new JLabel("Search by");
sby.setForeground(THEMECOLOR);
sby.setLabelFor(searchCriteria);
addNew.addActionListener(eventsHandler);
refreshAll.addActionListener(eventsHandler);
searchBar.add(sby);
searchBar.add(searchCriteria);
searchBar.add(addNew);
searchBar.add(refreshAll);
searchBar.setBackground(Color.DARK_GRAY);
scroll=new JScrollPane(stock);
stock.addMouseListener(new StockListener());
stock.setRowHeight(25);
stock.setComponentPopupMenu(popM);
stock.setFont(MotherFrame.tableFont);
stock.setSelectionBackground(THEMECOLOR);
stock.addKeyListener(eventsHandler);
stock.addMouseListener(eventsHandler);
this.setLayout(new BorderLayout());
this.add(scroll,BorderLayout.CENTER);
this.add(searchBar,BorderLayout.NORTH);
refreshMeals();
setCriteria();
groomDetailsView();
}
private void groomDetailsView()
{
mealDetails.setEditable(false);
mealDetails.setWrapStyleWord(true);
mealDetails.setText("");
mealDetails.setLineWrap(true);
detailsView.add(new JScrollPane(mealDetails),BorderLayout.CENTER);
JPanel buttons=new JPanel();
dismiss.addActionListener(eventsHandler);
printMeal.addActionListener(eventsHandler);
buttons.add(printMeal);
buttons.add(dismiss);
detailsView.add(buttons,BorderLayout.SOUTH);
}
private void viewDetails()
{
if(stock.getSelectedRow()!=-1)
{
mealDetails.setText("");
TableModel model=stock.getModel();
for(int i=0;i<model.getColumnCount();i++)
{
mealDetails.append("\n  "+model.getColumnName(i)+": "+model.getValueAt(stock.getSelectedRow(),i));
}
detailsView.setVisible(true);
selectedRow=0;
}
}
private void groomMenuAdder(int mode)
{
JPanel buttons=new JPanel();
addMeal.addActionListener(eventsHandler);
cancelAdd.addActionListener(eventsHandler);
saveChange.addActionListener(eventsHandler);
//buttons.add(addMeal);
buttons.add(cancelAdd);
mealName=new JTextField();
mealUnit=new JTextField();
mealCost=new JSpinner();
mealCost.setModel(new SpinnerNumberModel(100,1,1000000,5));
iko=new JComboBox();
category=new JComboBox();
String[] types=MotherFrame.MEALCATEGORIES;
for(String t1:types)
{
category.addItem(t1);
}
iko.addItem("Yes");
iko.addItem("No");
mealName.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE),"MEAL NAME"));
category.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE),"MEAL CLASS"));
mealUnit.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE),"SERVING UNIT"));
mealCost.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE),"PRICE/UNIT"));
iko.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE),"AVAILABLE"));
Container holder=menuAdder.getContentPane();
holder.removeAll();
holder.setLayout(new GridLayout(6,1));
holder.add(mealName);
holder.add(category);
holder.add(mealUnit);
holder.add(mealCost);
holder.add(iko);
holder.add(buttons);

switch(mode)
{
    case EDIT:
        buttons.add(saveChange);
        buttons.add(cancelAdd);
        fetchMealInfo();
        break;
    case ADD:
        buttons.add(addMeal);
        buttons.add(cancelAdd);
        break;
}
menuAdder.setVisible(true);
}
private void fetchMealInfo()
{
String id=(String)stock.getValueAt(stock.getSelectedRow(),0),
query="SELECT * FROM meals WHERE meal_id="+id+"",WHERE="fetchMealInfo():";
ResultSet info=MotherFrame.executeQuery(query);
    try 
    {
        if(info!=null&&info.first())
        {
        mealName.setText(info.getString("meal_name"));
        mealUnit.setText(info.getString("unit"));
        mealCost.setValue(info.getFloat("cost"));
        iko.setSelectedItem(info.getString("available"));
        category.setSelectedItem(info.getString("category"));
        }   
    }
    catch (Exception e)
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
}
private void setCriteria()
{
int cols=stock.getModel().getColumnCount();
searchCriteria.removeAllItems();
for(int t=0;t<cols;t++)
{
searchCriteria.addItem(stock.getModel().getColumnName(t).toUpperCase());
}
}
private void searchEntries()
{
   String text=searchText.getText(),field=(String)searchCriteria.getSelectedItem(),WHERE="searchEntries():";
   ResultSet data1=null;
   String getOrders="SELECT meal_id,meal_name,category,unit,cost,available FROM meals WHERE hotel_id="+MotherFrame.MY_ID+" AND "+field.toLowerCase()+" LIKE '%"+text+"%'";
   try
   {
   data1=MotherFrame.executeQuery(getOrders);
   stock.setModel(MotherFrame.getModel(data1));
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"SQL EXception Occured\n"+e.getMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }
   finally
   {
    try
    {
     data1.close();
    }
    catch (Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
  }
}
public void refreshMeals()
{
   ResultSet data1=null;
   String getBooks="SELECT meal_id,meal_name,category,unit,cost,available FROM meals WHERE hotel_id="+MotherFrame.MY_ID,WHERE="refreshStock():";
   try
   {
   data1=MotherFrame.executeQuery(getBooks);
   stock.setModel(MotherFrame.getModel(data1));
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"SQL EXception Occured\n"+e.getMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }
   finally
   {
    try
    {
     data1.close();
    }
    catch (Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
  }
   }
private void addMealToMenu()
{
String WHERE="addMealToMenu():";
String name=mealName.getText(),
        mealClass=(String)category.getSelectedItem(),
        sUnit=mealUnit.getText(),
        isThere=(String)iko.getSelectedItem();
float bei=Float.parseFloat(mealCost.getValue().toString());
if(!name.equals("")&&!mealClass.equals("")&&!sUnit.equals("")&&bei>1)
{
   String addMenu="INSERT INTO meals (meal_name,category,unit,cost,available,hotel_id) "
           + "VALUES('"+name+"','"+mealClass+"','"+sUnit+"',"+bei+",'"+isThere+"',"+MotherFrame.MY_ID+")";
   try
   {
   int rs=MotherFrame.executeUpdate(addMenu);
   stock.enableInputMethods(false);
   refreshMeals();
   mealName.setText("");
   category.setSelectedIndex(0);
   mealUnit.setText("");
   iko.setSelectedIndex(0);
   mealCost.setValue(100);
   JOptionPane.showMessageDialog(this,name+" added to menu","MEAL ADDED",JOptionPane.INFORMATION_MESSAGE);
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"An EXception Occured\n"+e.getMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }               
}
    else
    {
    JOptionPane.showMessageDialog(this,"Please Ensure that \nall the Details are entered before saving.","Missing Details",JOptionPane.WARNING_MESSAGE);
    }
}
private void updateMeal()
{
String WHERE="updateMeal():";
String name=mealName.getText(),
        mealClass=(String)category.getSelectedItem(),
        sUnit=mealUnit.getText(),
        isThere=(String)iko.getSelectedItem(),
        id=(String)stock.getValueAt(stock.getSelectedRow(),0);

float bei=Float.parseFloat(mealCost.getValue().toString());
if(!name.equals("")&&!mealClass.equals("")&&!sUnit.equals("")&&bei>1)
{
   String addMenu="UPDATE meals set meal_name='"+name+"',category='"+mealClass+"',unit='"+sUnit+"',cost="+bei
           +",available='"+isThere+"' WHERE meal_id='"+id+"'";
   try
   {
   int rs=MotherFrame.executeUpdate(addMenu);
   stock.enableInputMethods(false);
   refreshMeals();
   mealName.setText("");
   category.setSelectedIndex(0);
   mealUnit.setText("");
   iko.setSelectedIndex(0);
   mealCost.setValue(100);
   JOptionPane.showMessageDialog(this,name+" Updated Successfully","MEAL UPDATED",JOptionPane.INFORMATION_MESSAGE);
   }
   catch(Exception e)
   {
   JOptionPane.showMessageDialog(this,"An EXception Occured\n"+e.getMessage());
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
   }               
}
    else
    {
    JOptionPane.showMessageDialog(this,"Some details must be entered before commiting change\nPlease ensure all details are entered.","Missing Details",JOptionPane.WARNING_MESSAGE);
    }
}
private void chooseCommand()
{
String st=(String)stock.getValueAt(stock.getSelectedRow(),stock.getColumnCount()-1);
if(st.equalsIgnoreCase("Yes"))
{
popM.remove(setAvailable);
popM.add(setUnavailable);
}
else if(st.equalsIgnoreCase("No"))
{
popM.remove(setUnavailable);
popM.add(setAvailable);   
}
}
private void deleteEntry()
{
String meal=(String)stock.getValueAt(stock.getSelectedRow(),0);
String sql="DELETE FROM meals WHERE meal_id="+meal;
switch(JOptionPane.showConfirmDialog(this,"Delete "+meal.toUpperCase()+" Entry?", "DELETE ENTRY",JOptionPane.YES_NO_OPTION))
{
    case JOptionPane.YES_OPTION:
        if(MotherFrame.executeUpdate(sql)>0)
        {
        refreshMeals();
        //JOptionPane.showMessageDialog(this,"Deleted Successfully", "ENTRY DELETED ",JOptionPane.INFORMATION_MESSAGE);
        }
        break;
}
}
private void buttonClicked(JButton src)
{
    String WHERE="buttonClicked(JButton):";
  if(src.equals(addNew))
  {
   add.doClick();
  }
  if(src.equals(refreshAll))
  {
   refreshMeals();
  }
  else if(src.equals(saveChange))
  {
  dialogButtonClicked(saveChange);
  }
  else if(src.equals(addMeal))
  {
  dialogButtonClicked(addMeal);
  }
  else if(src.equals(cancelAdd))
  {
  dialogButtonClicked(cancelAdd);
  }
  else if(src.equals(dismiss))
  {
  detailsView.setVisible(false);
  }
  else if(src.equals(printMeal))
  {
      try
      {
        mealDetails.print();
      } 
      catch (PrinterException e) 
      {
        HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
      }
  }
}
public void dialogButtonClicked(JButton src)
{
        if(src.equals(addMeal))
        {
        addMealToMenu();
        }
        else if(src.equals(cancelAdd))
        {
        menuAdder.setVisible(false);
        }
        else if(src.equals(saveChange))
        {
        updateMeal();
        }
        }
private void popupMenuItemSelected(JMenuItem source)
{
if(source.equals(refresh))
{
refreshMeals();
}
else if(source.equals(add))
{
groomMenuAdder(1);
}
else if(source.equals(view))
{
this.viewDetails();
}
else if(source.equals(edit))
{
groomMenuAdder(EDIT);
}
else if(source.equals(setUnavailable))
{
String id=(String)stock.getValueAt(stock.getSelectedRow(),0);
String update="UPDATE meals SET available='No' WHERE meal_id='"+id+"'";
int er = MotherFrame.executeUpdate(update);
refreshMeals();
}
else if(source.equals(setAvailable))
{
String id=(String)stock.getValueAt(stock.getSelectedRow(),0);
String update="UPDATE meals SET available='Yes' WHERE meal_id='"+id+"'";
int er = MotherFrame.executeUpdate(update);
refreshMeals();
}
else if(source.equals(print))
{
stock.print(mealDetails.getGraphics());
}
else if(source.equals(delete))
{
deleteEntry();
}
}
private class StockListener implements MouseListener,ActionListener,KeyListener,PopupMenuListener
{

        @Override
        public void mouseClicked(MouseEvent e) 
        {
        int type=e.getID();
        switch(type)
        {
            case MouseEvent.MOUSE_CLICKED:
            switch(e.getButton())
            {
                case MouseEvent.BUTTON3:
                    popM.show(stock,e.getX(),e.getY());
                    e.consume();
                    break;
                case MouseEvent.BUTTON1:
                    if(e.getClickCount()==2)
                    {
                     viewDetails();
                    }
                    break;
            }
        }
        }
                @Override
        public void actionPerformed(ActionEvent e) 
        {
         if(e.getSource() instanceof JButton)
         {
         buttonClicked((JButton)e.getSource());
         }
         else if(e.getSource() instanceof JMenuItem)
         {
         JMenuItem source=(JMenuItem) e.getSource();
         popupMenuItemSelected(source);
         }
        }
        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {}

        @Override
        public void mouseExited(MouseEvent e) {}

        @Override
        public void keyTyped(KeyEvent e) 
        {
            if(e.getSource().equals(searchText))
            {
            searchEntries();
            }
            else if(e.getSource().equals(stock))
            {
            
            }
        }

        @Override
        public void keyPressed(KeyEvent e)
        {
         if(e.getSource().equals(stock)&&e.getKeyCode()==KeyEvent.VK_DELETE)
            {
            delete.doClick();
            }
        }

        @Override
        public void keyReleased(KeyEvent e) 
        {
          searchEntries();
        }

        @Override
        public void popupMenuWillBecomeVisible(PopupMenuEvent e) 
        {
            chooseCommand();
        }

        @Override
        public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {}

        @Override
        public void popupMenuCanceled(PopupMenuEvent e) {}
    }
}