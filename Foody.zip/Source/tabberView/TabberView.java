/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package tabberView;

import com.sun.glass.events.KeyEvent;
import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import javax.swing.JTabbedPane;

/**
 *
 * @author Eric Kamunge
 * @email kamungeeric@gmail.com
 */
public class TabberView extends JTabbedPane{
private final StaffPanel staffPane;
private final StockPanel stockPane;
private final OrdersPanel ordersPane;
private final ReservationsPanel reservationsPane;
private static final String MODULE="TabberView";
public TabberView()
{
String WHERE="Constructor:";
this.reservationsPane = new ReservationsPanel();
this.ordersPane = new OrdersPanel();
this.staffPane = new StaffPanel();
this.stockPane = new StockPanel();
try
{
this.add("            ORDERS            ",ordersPane);

this.add("          MAIN MENU           ",stockPane);
this.add("            RESERVATIONS      ",reservationsPane);
this.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
this.setMnemonicAt(0,KeyEvent.VK_O);
this.setMnemonicAt(1,KeyEvent.VK_M);
this.setMnemonicAt(2,KeyEvent.VK_R);if(MotherFrame.PRIVILEGE.equals("ADMIN"))
{
this.add("            STAFF             ",staffPane);
this.setMnemonicAt(3,KeyEvent.VK_S);
}
}
catch(Exception e)
{
HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
}

}

}
