/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drawables;

import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Eric
 */
public class Calculator extends JDialog{
private final JButton one,two,three,four,five,six,seven,eight,nine,zero,point,plus,minus,times,by,equals,off,clear,del,oo;
private final JTextField display;
private final EventsHandler eventsHandler;
private final Font forButtons=new Font(Font.DIALOG_INPUT,Font.BOLD,20);
private final JLabel workArea;
private float first;
private char operator;
private static final String MODULE="Calculator:";

    public Calculator()
    {
     eventsHandler=new EventsHandler();
     this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
     this.setIconImage(MotherFrame.icon);
     this.setSize(400,350);
     this.setMinimumSize(new Dimension(350,300));
     this.setAlwaysOnTop(true);
     Container p=this.getContentPane();
     JPanel parent=new JPanel();
     parent.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY,3,true));
     parent.setLayout(new BorderLayout());
     workArea=new JLabel("0.0");
     display=new JTextField("0",10);
     workArea.setFont(new Font(Font.SERIF,Font.LAYOUT_RIGHT_TO_LEFT,20));
     workArea.setBackground(display.getBackground());
     display.setAlignmentX(CENTER_ALIGNMENT);
     display.setEditable(false);
     display.addKeyListener(eventsHandler);
     display.setFont(new Font(Font.MONOSPACED,Font.BOLD,35));
     display.setBorder(BorderFactory.createTitledBorder(""));
     JPanel working=new JPanel(),
             screen=new JPanel();
     screen.setBorder(BorderFactory.createLineBorder(Color.BLUE));
     screen.setLayout(new BorderLayout());
     screen.add(workArea,BorderLayout.NORTH);
     screen.add(display,BorderLayout.CENTER);
     working.setBorder(BorderFactory.createLineBorder(Color.GRAY,3));
     working.setLayout(new GridLayout(5,4));
     zero=new JButton("0");
     one=new JButton("1");
     two=new JButton("2");
     three=new JButton("3");
     four=new JButton("4");
     five=new JButton("5");
     six=new JButton("6");
     seven=new JButton("7");
     eight=new JButton("8");
     nine=new JButton("9");
     point=new JButton(".");
     plus=new JButton("+");
     minus=new JButton("-");
     times=new JButton("*");
     by=new JButton("/");
     equals=new JButton("=");
     oo=new JButton("00");
     clear=new JButton("C");
     off=new JButton("OFF");
     del=new JButton("Del");
     off.setBackground(Color.RED);
     JButton[] all={oo,clear,del,off,one,two,three,four,five,six,seven,eight,nine,zero,point,plus,minus,times,by,equals},
             other={oo,clear,del,off,one,two,three,plus,four,five,six,minus,seven,eight,nine,times,point,zero,by,equals};
    for (JButton b : other) 
    {
    working.add(b);
    }
    for (JButton b : all) 
    {
    b.setFont(forButtons);
    b.addKeyListener(eventsHandler);
    b.addActionListener(eventsHandler);
    }
    parent.add(screen,BorderLayout.NORTH);
    parent.add(working,BorderLayout.CENTER);
    p.add(parent);
    }
    private void functionClicked(JButton key)
    {
        String WHERE="functionClicked():";
        if(!key.equals(equals)&&!key.equals(clear)&&!key.equals(off)&&!key.equals(del))
        {
        try
        {
        doMaths();
        }
        catch(Exception e)
        {
        HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
        }
        }
        if(key.equals(plus))
        {
        operator='+';
        }
        else if(key.equals(minus))
        {
        operator='-';
        }
        else if(key.equals(by))
        {
        operator='/';
        }
        else if(key.equals(times))
        {
        operator='*';
        }
        else if(key.equals(equals))
        {
        doMaths();
        workArea.setText(display.getText());
        operator='d';
        }
        else if(key.equals(off))
        {
        this.setVisible(false);
        }
        else if(key.equals(clear))
        {
        display.setText("0");
        }
        else if(key.equals(del))
        {
        deleteDigits();
        }
        if(!key.equals(equals)&&!key.equals(clear)&&!key.equals(off)&&!key.equals(del))
        {
        try
        {
        first=Float.parseFloat(display.getText());
        display.setText("0");
        workArea.setText(first+""+operator);
        }
        catch(Exception e)
        {
        HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
        }
        }
        }
    private void numberKeyed(JButton key)
    {
        if(display.getText().equals("0")&&!key.equals(point))
        {
        display.setText("");
        }
        if(key.equals(one))
        {
        display.setText(display.getText()+"1");
        }
        else if(key.equals(two))
        {
        display.setText(display.getText()+"2");
        }
        else if(key.equals(three))
        {
        display.setText(display.getText()+"3");
        }
        else if(key.equals(four))
        {
        display.setText(display.getText()+"4");
        }
        else if(key.equals(five))
        {
        display.setText(display.getText()+"5");
        }
        else if(key.equals(six))
        {
        display.setText(display.getText()+"6");
        }
        else if(key.equals(seven))
        {
        display.setText(display.getText()+"7");
        }
        else if(key.equals(eight))
        {
        display.setText(display.getText()+"8");
        }
        else if(key.equals(nine))
        {
        display.setText(display.getText()+"9");
        }
        else if(key.equals(zero))
        {
        display.setText(display.getText()+"0");
        }
        else if(key.equals(oo))
        {
        display.setText(display.getText()+"00");
        }
        else if(key.equals(point))
        {
        if(display.getText().indexOf('.')==-1)
        {
        display.setText(display.getText()+".");
        }
        else
        {
        Toolkit.getDefaultToolkit().beep();
        }
        }
        }
    private void doMaths()
    {
    if(operator=='+')
    {
    getSum();
    }
    else if(operator=='-')
    {
    getDifference();
    }
    else if(operator=='*')
    {
    getProduct();
    }
    else if(operator=='/')
    {
    getQuotient();
    }
    }
    private void getSum()
    {
     String WHERE="getSum():";
    try
    {
    float second=Float.parseFloat(display.getText());
    display.setText((second+first)+"");
    }
    catch(Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    private void getQuotient()
    {
     String WHERE="getQuotient():";
    try
    {
    float second=Float.parseFloat(display.getText());
    display.setText((first/second)+"");
    }
    catch(Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    private void getDifference()
    {
    String WHERE="getDifference():";
    try
    {
    float second=Float.parseFloat(display.getText());
    display.setText((first-second)+"");
    }
    catch(Exception e)
    {
   HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    private void getProduct()
    {
     String WHERE="getProduct():";
    try
    {
    float second=Float.parseFloat(display.getText());
    display.setText((first*second)+"");
    }
    catch(Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    private void deleteDigits()
    {
    String curr=display.getText(),WHERE="deleteDigits():";
    if(curr.length()!=1)
    {
    try
    {
    String nw=curr.substring(0,curr.length()-1);
    display.setText(nw);
    }
    catch(Exception e)
    {
    HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
    }
    else if(display.getText().length()==1)
    {
    display.setText("0");
    }
    }
    private void getCharTyped(char cc)
    {
    JButton[] all={zero,one,two,three,four,five,six,seven,eight,nine,point,plus,minus,times,by,equals,clear};
    for (JButton all1 : all)
    {
        if (all1.getText().equals(cc+""))
        {
            all1.doClick();
            break;
        }
    }
    }
private class EventsHandler implements KeyListener,ActionListener{
        @Override
        public void keyTyped(KeyEvent e){}
        @Override
        public void keyPressed(KeyEvent e)
        {
        switch(e.getKeyCode())
        {
            case KeyEvent.VK_BACK_SPACE:
                del.doClick();
                e.consume();
                break;
            default:
                getCharTyped(e.getKeyChar());
                break;
        }
        }
        @Override
        public void keyReleased(KeyEvent e){}
        
        @Override
        public void actionPerformed(ActionEvent e) 
        {
        if(e.getSource() instanceof JButton)
        {
        JButton src=(JButton) e.getSource();
        if(src.equals(one)||src.equals(two)||src.equals(three)||src.equals(four)
                ||src.equals(five)||src.equals(six)||src.equals(seven)||src.equals(eight)
                ||src.equals(nine)||src.equals(zero)||src.equals(point)||src.equals(oo))
        {
        numberKeyed(src);
        }
        else if(src.equals(plus)||src.equals(minus)||src.equals(times)||src.equals(by)||src.equals(equals)
        ||src.equals(clear)||src.equals(off)||src.equals(del))
        {
        functionClicked(src);
        }
        }
        }

}
}