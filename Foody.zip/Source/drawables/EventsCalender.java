/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drawables;

import hotelbiller.HotelBiller;
import hotelbiller.MotherFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.UtilDateModel;

/**
 *
 * @author Eric
 */
public class EventsCalender extends JPanel{
private  JTextArea eventNote,note;
private JTextField title,venue;
private  JButton saveButton,reset,update,cancel;
private final JButton exit;
private JSpinner hour,min;
private final JDatePanelImpl calender;
private final Font forFields=new Font(Font.DIALOG_INPUT,Font.ITALIC,15);
private final MenuItem refresh,edit,delete;
private final PopupMenu popM;
private final JPanel adderPanel,btn;
private final JLabel dateLabel;
private final List events;
private final Properties todos;
private static final String MODULE="EventsCalender:";
private int editing;
private final Font forAll=new Font(Font.SANS_SERIF,Font.ITALIC|Font.BOLD,30),
        forNote=new Font(Font.SERIF, Font.ITALIC,15);
private final EventsHandler eventsHandler;
public EventsCalender()
{
eventsHandler=new EventsHandler();
this.setLayout(new BorderLayout());
refresh=new MenuItem("Refresh");
refresh.addActionListener(eventsHandler);
delete=new MenuItem("Delete");
delete.addActionListener(eventsHandler);
edit=new MenuItem("Edit Event");
edit.addActionListener(eventsHandler);
popM=new PopupMenu();
popM.add(edit);
popM.addSeparator();
popM.add(delete);
popM.addSeparator();
popM.add(refresh);
popM.addSeparator();
popM.addActionListener(eventsHandler);
todos=new Properties();
adderPanel=new JPanel();
btn=new JPanel();
events=new List();
events.add(popM);
events.addItemListener(eventsHandler);
events.addMouseListener(eventsHandler);
events.setMultipleMode(false);
events.setPreferredSize(new Dimension(300,300));
createAdder();
UtilDateModel um=new UtilDateModel();
um.setDate(2016,6,20);
Properties p=new Properties();
p.put("text.today","Today");
p.put("text.month","Month");
p.put("text.year","Year");
calender=new JDatePanelImpl(um,p);
calender.addMouseListener(eventsHandler);
calender.addActionListener(eventsHandler);
calender.setPreferredSize(new Dimension(300,200));
calender.setFont(forAll);
calender.setShowYearButtons(true);
calender.setRequestFocusEnabled(true); 
calender.setVisible(true);
dateLabel=new JLabel("Date: "+calender.getModel().getDay()+"-"+(calender.getModel().getMonth()+1)+"-"+calender.getModel().getYear());
dateLabel.setFont(forAll);
dateLabel.setBackground(Color.RED);
dateLabel.setHorizontalAlignment(SwingConstants.CENTER);
dateLabel.setForeground(Color.BLUE);
eventNote=new JTextArea();
eventNote.setFont(forNote);
eventNote.setEditable(false);
eventNote.setAlignmentX(SwingConstants.CENTER);
eventNote.setBorder(BorderFactory.createTitledBorder("Details"));
eventNote.setPreferredSize(new Dimension(200,200));
exit=new JButton("Exit Events Calender");
exit.addActionListener(eventsHandler);
update=new JButton("Update");
update.addActionListener(eventsHandler);
cancel=new JButton("Cancel");
cancel.addActionListener(eventsHandler);
JPanel pp=new JPanel(),
        norther=new JPanel(),
        cent=new JPanel();
cent.setLayout(new GridLayout(1,2));
cent.add(new JScrollPane(events));
cent.add(new JScrollPane(eventNote));
norther.setLayout(new GridLayout(1,2));
norther.add(new JScrollPane(calender));
norther.add(adderPanel);
pp.setLayout(new BorderLayout());
pp.add(dateLabel,BorderLayout.NORTH);
pp.add(cent,BorderLayout.CENTER);
this.add(norther,BorderLayout.NORTH);
this.add(pp,BorderLayout.CENTER);
this.add(exit,BorderLayout.SOUTH);
fetchDateEvents();
}
private void createAdder()
{
title=new JTextField();
title.setFont(forFields);
title.setPreferredSize(new Dimension(400,30));
title.setHorizontalAlignment(SwingConstants.CENTER);
venue=new JTextField();
venue.setHorizontalAlignment(SwingConstants.CENTER);
venue.setFont(forFields);
venue.setPreferredSize(new Dimension(150,30));
note=new JTextArea();
note.setFont(forFields);
note.setPreferredSize(new Dimension(350,100));
saveButton=new JButton("Save");
saveButton.setPreferredSize(new Dimension(100,30));
saveButton.addActionListener(eventsHandler);
reset=new JButton("Reset");
reset.setPreferredSize(new Dimension(100,30));
reset.addActionListener(eventsHandler);
hour=new JSpinner();
hour.setModel(new SpinnerNumberModel(00,0,23,1));
min=new JSpinner();
min.setModel(new SpinnerNumberModel(0,0,59,1));
JPanel time=new JPanel();
time.add(new JLabel("Hr"));
time.add(hour);
time.add(new JLabel("Min"));
time.add(min);
adderPanel.setLayout(new BorderLayout());
JPanel norther=new JPanel(),
        tv=new JPanel(),
        tm=new JPanel(),
        v=new JPanel();
note.setBorder(BorderFactory.createTitledBorder("NOTE"));
title.setBorder(BorderFactory.createTitledBorder("TITLE"));
tm.setBorder(BorderFactory.createTitledBorder("TIME"));
tm.add(time);
tv.setLayout(new GridLayout(1,2));
tv.setPreferredSize(new Dimension(200,80));
v.setBorder(BorderFactory.createTitledBorder("VENUE"));
v.add(venue);
tv.add(v);
tv.add(tm);
btn.add(reset);
btn.add(saveButton);
norther.setLayout(new GridLayout(2,1));
norther.setPreferredSize(new Dimension(200,150));
norther.add(title);
norther.add(tv);
adderPanel.add(norther,BorderLayout.NORTH);
adderPanel.add(new JScrollPane(note),BorderLayout.CENTER);
adderPanel.add(btn,BorderLayout.SOUTH);
adderPanel.setBorder(BorderFactory.createTitledBorder("ADD NEW EVENT"));
}
private void listSelectionChanged()
{
Event ev=(Event) todos.get(events.getSelectedItem());
eventNote.setText("");
eventNote.setToolTipText(ev.title);
eventNote.append("\n***************************************");
eventNote.append("\nREF NO: EVENT"+ev.ref);
eventNote.append("\nEVENT: "+ev.title);
eventNote.append("\nTIME: "+ev.date);
eventNote.append("\nVENUE: "+ev.place);
eventNote.append("\nNOTE: \n"+ev.note);
}
private void buttonClicked(JButton src)
{
if(src.equals(exit))
{
MotherFrame.panelSwitched(this);
}
else if(src.equals(saveButton))
{
addEvent(saveButton);
}
else if(src.equals(update))
{
addEvent(update);
}
else if(src.equals(reset))
{
title.setText("");
note.setText("");
venue.setText("");
}
else if(src.equals(cancel))
{
btn.remove(cancel);
btn.remove(update);
btn.add(saveButton);
btn.add(reset);
btn.validate();
btn.repaint();
reset.doClick();
}
}
private void initiateEdit()
{
btn.remove(saveButton);
btn.remove(reset);
btn.add(update);
btn.add(cancel);
Event ev=(Event) todos.get(events.getSelectedItem());
editing=ev.ref;
title.setText(ev.title);
note.setText(ev.note);
venue.setText(ev.place);
btn.validate();
btn.repaint();
}
private void fetchDateEvents()
{
String WHERE="fetchDateEvents():";
ResultSet rs;
String day=""+calender.getModel().getDay(),month=""+(calender.getModel().getMonth()+1),year=""+calender.getModel().getYear();
if(day.length()==1)
{
day="0"+day;
}
if(month.length()==1)
{
month="0"+month;
}
String like=year+"-"+month+"-"+day;
dateLabel.setText(like);
String sql="SELECT * FROM EVENTS WHERE TIME LIKE'%"+like+"%'";
rs=MotherFrame.executeQuery(sql);
eventNote.setText("");
if(rs!=null)
{
    try
    {
        events.removeAll();
        todos.clear();
        Event one;
        while(rs.next())
        {
            one=new Event();
            events.add(rs.getString("REFNO")+". "+rs.getString("TITLE"));
            one.ref=rs.getInt("REFNO");
            one.title=rs.getString("TITLE");
            one.date=rs.getString("TIME");
            one.place=rs.getString("VENUE");
            one.note=rs.getString("NOTE");
            todos.put(rs.getString("REFNO")+". "+rs.getString("TITLE"),one);
            if(rs.isFirst())
            {
            eventNote.setToolTipText(one.title);
            eventNote.append("\n***************************************");
            eventNote.append("\nREF NO: EVENT"+rs.getString("REFNO"));
            eventNote.append("\nEVENT: "+rs.getString("TITLE"));
            eventNote.append("\nTIME: "+rs.getString("TIME"));
            eventNote.append("\nVENUE: "+rs.getString("VENUE"));
            eventNote.append("\nNOTE: \n"+rs.getString("NOTE"));
            }
        }
        rs.close();
    }
    catch (SQLException e)
    {
     HotelBiller.queueError(MODULE+WHERE+e.toString()+":"+e.getMessage());
    }
}
else
{

}
}
private void popupMenuSelected(MenuItem it)
{
if(it.equals(delete))
{
    switch(JOptionPane.showConfirmDialog(events,"Delete this Event ?\n"+events.getSelectedItem(),"Confirm Delete",JOptionPane.YES_NO_OPTION))
    {
        case JOptionPane.YES_OPTION:
            deleteEvent();
            break;
        case JOptionPane.NO_OPTION:
            break;
    }
}
else if(it.equals(edit))
{
initiateEdit();
}
else if(it.equals(refresh))
{
fetchDateEvents();
}
}
private void deleteEvent()
{
Event ev=(Event) todos.get(events.getSelectedItem());
String sql="DELETE FROM EVENTS WHERE REFNO="+ev.ref+"";
int i=MotherFrame.executeUpdate(sql);
if(i!=0){JOptionPane.showMessageDialog(this,"Deleted","Event Deleted",JOptionPane.INFORMATION_MESSAGE);}
fetchDateEvents();
}
private void addEvent(JButton action) 
{
if(!venue.getText().equals("")&&!title.getText().equals("")&&!note.getText().equals(""))
{
String tt=title.getText(),ve=venue.getText(),nt=note.getText(),hr=""+hour.getValue(),mn=""+min.getValue();
String day=""+calender.getModel().getDay(),month=""+(calender.getModel().getMonth()+1),year=""+calender.getModel().getYear();
if(day.length()==1)
{
day="0"+day;
}
if(month.length()==1)
{
month="0"+month;
}
String date=year+"-"+month+"-"+day+" "+hr+':'+mn+':'+00;
String sql;
int d=0;
if(action.equals(saveButton))
{
sql="INSERT INTO EVENTS(TITLE,VENUE,NOTE,TIME) VALUES('"+tt+"','"+ve+"','"+nt+"','"+date+"')";
d=MotherFrame.executeUpdate(sql);
}
else if(action.equals(update))
{
sql="UPDATE EVENTS SET TITLE='"+tt+"',VENUE='"+ve+"',NOTE='"+nt+"',TIME='"+date+"' WHERE REFNO="+editing;
d=MotherFrame.executeUpdate(sql);
if(d!=0)
{
fetchDateEvents();
btn.remove(cancel);
btn.remove(update);
btn.add(saveButton);
btn.add(reset);
btn.validate();
btn.repaint();
reset.doClick();
}
}
if(d==1)
{
JOptionPane.showMessageDialog(this,"Successful","DONE",JOptionPane.INFORMATION_MESSAGE);
reset.doClick();
}
else
{
JOptionPane.showMessageDialog(this,"Error Occured Adding Event","ERROR OCCURRED",JOptionPane.INFORMATION_MESSAGE);
}
}
else
{
JOptionPane.showMessageDialog(this,"Please enter the missing values first","MISSING VALUES",JOptionPane.INFORMATION_MESSAGE);
}
}
public class EventsHandler implements ActionListener,MouseListener,ItemListener{

        @Override
        public void actionPerformed(ActionEvent e) 
        {
        if(e.getSource() instanceof JButton)
        {
        buttonClicked((JButton)e.getSource());
        }
        else if(e.getSource() instanceof JDatePanelImpl)
        {
        if(e.getSource().equals(calender))
        {
        fetchDateEvents();
        }
        }
        else if(e.getSource() instanceof List)
        {
        listSelectionChanged();
        }
        else if(e.getSource() instanceof MenuItem)
        {
        popupMenuSelected((MenuItem)e.getSource());
        }
        }

        @Override
        public void mouseClicked(MouseEvent e) 
        {
        switch(e.getButton())
        {
            case MouseEvent.BUTTON3:
                popM.show(events,e.getX(),e.getY());
                break;
            case MouseEvent.BUTTON1:
                if(e.getSource().equals(events))
                {
                }
                break;
        }
        }
        @Override
        public void mousePressed(MouseEvent e){}
        @Override
        public void mouseReleased(MouseEvent e){}
        @Override
        public void mouseEntered(MouseEvent e) {}
        @Override
        public void mouseExited(MouseEvent e) {}

        @Override
        public void itemStateChanged(ItemEvent e)
        {
         if(e.getSource() instanceof List && e.getStateChange()==ItemEvent.SELECTED)
         {
          listSelectionChanged();
         }
        }
    }
private class Event
{
public String title,date,place,note;
public int ref;
public Event()
{
title="";
date="";
place="";
note="";
}
}
}